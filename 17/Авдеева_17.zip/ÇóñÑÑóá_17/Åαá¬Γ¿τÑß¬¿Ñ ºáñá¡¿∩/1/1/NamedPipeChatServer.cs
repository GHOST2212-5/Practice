﻿using System;
using System.IO.Pipes;
using System.Text;

namespace X.Services
{
    public class NamedPipeChatServer
    {
        private NamedPipeServerStream _server;
        public async void StartServer()
        {
            _server = new NamedPipeServerStream("LocalChatPipe", PipeDirection.InOut);
            await _server.WaitForConnectionAsync();

            while (true)
            {
                byte[] b = new byte[256];
                int br = await _server.ReadAsync(b, 0, b.Length);
                string message = Encoding.UTF8.GetString(b, 0, br);
                OnMessageReceived?.Invoke(message);
            }
        }
        public event Action<string> OnMessageReceived;
    }
}