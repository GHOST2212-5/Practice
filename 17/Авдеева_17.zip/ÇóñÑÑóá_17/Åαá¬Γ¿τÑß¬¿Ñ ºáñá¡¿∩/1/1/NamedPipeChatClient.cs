﻿using System.IO.Pipes;
using System.Text;
using System.Threading.Tasks;

namespace X.Services
{
    public class NamedPipeChatClient
    {
        public async Task SendMessage(string message)
        {
            using var client = new NamedPipeClientStream(".", "LocalChatPipe", PipeDirection.Out);
            await client.ConnectAsync();
            byte[] b = Encoding.UTF8.GetBytes(message);
            await client.WriteAsync(b, 0, b.Length);
        }
    }
}