﻿using System;
using System.IO;

namespace X.Services
{
    public class OrderWatcher
    {
        private readonly FileSystemWatcher _watcher;
        public OrderWatcher(string path)
        {
            _watcher = new FileSystemWatcher(path)
            {
                NotifyFilter = NotifyFilters.LastWrite | NotifyFilters.FileName,
                Filter = "*.json"
            };
            _watcher.Changed += OnChanged;
            _watcher.EnableRaisingEvents = true;
        }
        private void OnChanged(object sender, FileSystemEventArgs e)
        {
            OnOrderChanged?.Invoke($"Изменён файл: {e.FullPath}");
        }

        public event Action<string> OnOrderChanged;
    }
}