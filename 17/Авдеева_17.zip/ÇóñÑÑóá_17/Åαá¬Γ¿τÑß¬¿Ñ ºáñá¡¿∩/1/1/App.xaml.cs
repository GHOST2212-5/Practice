﻿using System;
using System.Windows;
using X;
using X.Services;

namespace _1
{
    public partial class App : Application
    {
        private readonly UserManager userManager;
        public App()
        {
            userManager = new UserManager();
        }
        protected override void OnStartup(StartupEventArgs e)
        {
            base.OnStartup(e);
            try
            {
                var loginWindow = new LoginWindow(userManager);
                loginWindow.ShowDialog();

                if (loginWindow.IsAuthenticated)
                {
                    var mainWindow = new MainWindow();
                    Current.MainWindow = mainWindow;
                    mainWindow.Show();
                    loginWindow.Close();
                }
                else
                {
                    Shutdown();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка запуска: {ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                Shutdown();
            }
        }
    }
}