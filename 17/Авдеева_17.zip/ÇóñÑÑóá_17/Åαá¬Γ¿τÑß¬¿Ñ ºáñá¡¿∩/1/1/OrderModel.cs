﻿using System.ComponentModel;

namespace X.Models
{
    public class OrderModel : INotifyPropertyChanged
    {
        private int orderId;
        private string clientName;
        public int OrderId
        {
            get => orderId;
            set { orderId = value; OnPropertyChanged(nameof(OrderId)); }
        }
        public string ClientName
        {
            get => clientName;
            set { clientName = value; OnPropertyChanged(nameof(ClientName)); }
        }
        public event PropertyChangedEventHandler PropertyChanged;
        protected void OnPropertyChanged(string pn)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(pn));
        }
    }
}