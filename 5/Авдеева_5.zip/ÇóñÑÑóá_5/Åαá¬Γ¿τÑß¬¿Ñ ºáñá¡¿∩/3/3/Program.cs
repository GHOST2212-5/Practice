﻿using System;

class F
{
    public static int f(int n)
    {
        if (n <= 0)
        {
            throw new ArgumentException("Номер числа Фибоначчи строго больше 0.");
        }

        if (n == 1 || n == 2)
        {
            return 1;
        }

        return f(n - 1) + f(n - 2);
    }

    static void Main()
    {
        try
        {
            Console.Write("Введите номер числа Фибоначчи: ");
            int n = int.Parse(Console.ReadLine());

            int r = f(n);
            Console.WriteLine($"Fibonacci({n}) -> {r}.");
        }
        catch (Exception e)
        {
            Console.WriteLine($"{e.Message}");
        }
    }
}
