﻿using System;

namespace A
{
    public abstract class Animal
    {
        public abstract void MakeSound();
        public virtual void Sleep()
        {
            Console.WriteLine("У животного тихий час!");
        }
    }
    public class Dog : Animal
    {
        public override void MakeSound()
        {
            Console.WriteLine("Woof!");
        }
        public override void Sleep()
        {
            Console.WriteLine("Собака спит в будке");
        }
    }
    public class Cat : Animal
    {
        public override void MakeSound()
        {
            Console.WriteLine("Meow!");
        }
        public override void Sleep()
        {
            Console.WriteLine("Кот спит у холодильника");
        }
    }

    class Program
    {
        static void Main()
        {
            Animal myDog = new Dog();
            Animal myCat = new Cat();

            Console.WriteLine("Собака:");
            myDog.MakeSound();
            myDog.Sleep();
            Console.WriteLine("\nКот:");
            myCat.MakeSound();
            myCat.Sleep();
        }
    }
}
