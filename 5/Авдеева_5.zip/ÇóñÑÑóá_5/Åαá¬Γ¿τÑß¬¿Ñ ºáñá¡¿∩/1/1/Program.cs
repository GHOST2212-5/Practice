﻿using System;

class SM
{
    public static int AS(int[] nums)
    {
        int s = 0;
        for (int i = 0; i < nums.Length; i++)
        {
            s += nums[i];
        }
        return s;
    }

    static void Main()
    {
        int[] a = { 1, 2, 3, 4, 5 };
        int r = AS(a);

        Console.WriteLine($"Сумма элементов массива равна {r}.");
    }
}
