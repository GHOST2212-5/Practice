﻿using System;

class PA234
{
    public static void PowerA234(double A, out double B, out double C, out double D)
    {
        B = A * A;
        C = B * A;
        D = C * A;

    }

    static void Main()
    {
        double[] ns = { 2.0, 3.5, 1.2, 4.0, 5.5 };
        Console.WriteLine("  Вычисление степеней для данных чисел");

        foreach (var n in ns)
        {
            double s, t, f;
            PowerA234(n, out s, out t, out f);

            Console.WriteLine($"Число: {n}");
            Console.WriteLine($"  Степень 2: {s}");
            Console.WriteLine($"  Степень 3: {t}");
            Console.WriteLine($"  Степень 4: {f}");
            Console.WriteLine();

        }
    }
}
