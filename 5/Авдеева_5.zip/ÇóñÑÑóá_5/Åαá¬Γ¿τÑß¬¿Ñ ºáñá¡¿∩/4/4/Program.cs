﻿using System;

namespace ME
{
    public static class I
    {
        public static bool E(this int n)
        {
            return n % 2 == 0;
        }
    }

    class Me
    {
        static void Main()
        {
            Console.Write("Введите число: ");
            int p = int.Parse(Console.ReadLine());

            if (p.E())
            {
                Console.WriteLine($"{p} чётное.");
            }
            else
            {
                Console.WriteLine($"{p} нечётное.");
            }
        }
    }
}
