﻿using System;

abstract class BankAccount
{
    public string AccountNumber { get; set; }
    public double Balance { get; set; }
    public string OwnerName { get; set; }
    public BankAccount(string accountNumber, double balance, string ownerName)
    {
        AccountNumber = accountNumber;
        Balance = balance;
        OwnerName = ownerName;
    }
}

sealed class SavingsAccount : BankAccount
{
    public SavingsAccount(string accountNumber, double balance, string ownerName)
        : base(accountNumber, balance, ownerName)
    {
    }
}

sealed class CheckingAccount : BankAccount
{
    public CheckingAccount(string accountNumber, double balance, string ownerName)
        : base(accountNumber, balance, ownerName)
    {
    }
}

class Bank
{
    private BankAccount[] cas;
    public Bank(BankAccount[] cas)
    {
        this.cas = cas;
    }
    public BankAccount GetRichestClient()
    {
        BankAccount r = cas[0];
        foreach (var ca in cas)
        {
            if (ca.Balance > r.Balance)
            {
                r = ca;
            }
        }
        return r;
    }
    public double GetTotalBankBalance()
    {
        double totalBalance = 0;
        foreach (var ca in cas)
        {
            totalBalance += ca.Balance;
        }
        return totalBalance;
    }
    public string GN()
    {
        string[] ns = new string[cas.Length];
        for (int i = 0; i < cas.Length; i++)
        {
            ns[i] = cas[i].OwnerName;
        }
        return string.Join(", ", ns);
    }
}

class BA
{
    static void Main()
    {
        BankAccount[] cas = new BankAccount[]
        {
            new SavingsAccount("SA001", 1500.50, "Ангелины Авдеевой"),
            new CheckingAccount("CA002", 1500.00, "Дарьи Лукьяновой"),
            new SavingsAccount("SA003", 1500.05, "Ангелины Тучи")
        };

        Bank bank = new Bank(cas);

        BankAccount r = bank.GetRichestClient();
        Console.WriteLine($"Баланс больше у {r.OwnerName}, он равен {r.Balance}");

        double totalBalance = bank.GetTotalBankBalance();
        string CN = bank.GN();
        Console.WriteLine($"Общий баланс всех клиентов ({CN}) равен {totalBalance}.");
    }
}
