﻿using System;

class IS
{
    static void Main()
    {
        Order[] os = new Order[]
        {
            new Order(1, "Ангелина Авдеева", 1500.50m),
            new Order(2, "Дарья Лукьянова", 2500.00m),
            new Order(3, "Ангелина Туча", 750.00m)
        };

        Store store = new Store(os);

        Console.WriteLine("Все заказы:");
        foreach (var o in os)
        {
            o.Display();
        }

        decimal minAmount = 2000m;
        var highValueOrders = store.GetHighValueOrders(minAmount);
        Console.WriteLine($"\nЗаказы дороже {minAmount}:");
        foreach (var o in highValueOrders)
        {
            o.Display();
        }

        string customerName = "Ангелина Авдеева";
        var customerOrders = store.GetOrdersByCustomer(customerName);
        Console.WriteLine($"\nЗаказы клиента {customerName}:");
        foreach (var o in customerOrders)
        {
            o.DisplayBasicInfo();
        }
    }
}