using System;
using System.Linq;

class Store
{
    private Order[] os;

    public Store(Order[] os)
    {
        this.os = os;
    }

    public Order[] GetHighValueOrders(decimal minAmount)
    {
        return os.Where(o => o.TotalAmount > minAmount).ToArray();
    }

    public Order[] GetOrdersByCustomer(string customerName)
    {
        return os.Where(o => o.CustomerName == customerName).ToArray();
    }
}