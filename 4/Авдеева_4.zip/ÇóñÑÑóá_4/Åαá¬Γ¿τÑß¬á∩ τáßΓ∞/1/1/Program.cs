﻿using System;

class A
{
    private int a;
    private int b;

    public A(int a, int b)
    {
        this.a = a;
        this.b = b;
    }

    public int M()
    {
        return a - b;
    }

    public double C()
    {
        if (a - b == 0)
        {
            throw new DivideByZeroException("Знаменатель не может быть равен 0.");
        }
        return (double)(a + b) / (a - b);
    }

    public void D()
    {
        Console.WriteLine($"Вы ввели значение a равное {a}");
        Console.WriteLine($"Вы ввели значение b равное {b}");
    }
}

class Example
{
    static void Main()
    {
        int VA = 0, VB = 0;
        bool IA = false, IB = false;

        while (!IA)
        {
            try
            {
                Console.Write("Введите a: ");
                VA = Convert.ToInt32(Console.ReadLine());
                IA = true;
            }
            catch (FormatException)
            {
                Console.WriteLine("Было введено не целое число.");
            }
        }

        while (!IB)
        {
            try
            {
                Console.Write("Введите b: ");
                VB = Convert.ToInt32(Console.ReadLine());
                IB = true;
            }
            catch (FormatException)
            {
                Console.WriteLine("Было введено не целое число.");
            }
        }

        try
        {
            A obj = new A(VA, VB);
            obj.D();

            Console.WriteLine($"(a - b) = {obj.M()}");
            Console.WriteLine($"(a + b) / (a - b) = {obj.C()}");
        }
        catch (DivideByZeroException ex)
        {
            Console.WriteLine($"{ex.Message}");
        }
    }
}
