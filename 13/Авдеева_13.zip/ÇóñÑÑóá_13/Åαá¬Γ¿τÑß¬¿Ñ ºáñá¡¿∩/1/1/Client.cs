﻿public class Client
{
    public string Name { get; set; }
    public string Contact { get; set; }
    public string InteractionHistory { get; set; }
}