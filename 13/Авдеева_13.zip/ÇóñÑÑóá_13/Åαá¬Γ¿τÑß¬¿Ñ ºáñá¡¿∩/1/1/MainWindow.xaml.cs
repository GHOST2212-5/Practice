﻿using System.Collections.ObjectModel;
using System.Windows;

namespace X
{
    public partial class MainWindow : Window
    {
        public ObservableCollection<Client> Clients { get; set; }
        public MainWindow()
        {
            InitializeComponent();
            Clients = new ObservableCollection<Client>
            {
                new Client
                {
                    Name = "Ангелина Авдеева",
                    Contact = "+37529. . . . . . .",
                    InteractionHistory = "Первичный контакт"
                },
                new Client
                {
                    Name = "Имя Фамилия",
                    Contact = "+3752912345679",
                    InteractionHistory = "Информация"
                }
            };
            DataContext = Clients;
        }
        private void AddButton_Click(object sender, RoutedEventArgs e)
        {
            var form = new ClientFormWindow();
            if (form.ShowDialog() == true)
            {
                Clients.Add(form.Client);
            }
        }
        private void EditButton_Click(object sender, RoutedEventArgs e)
        {
            if (ClientListView.SelectedItem is Client SC)
            {
                var form = new ClientFormWindow(SC);
                if (form.ShowDialog() == true)
                {
                    ClientListView.Items.Refresh();
                }
            }
            else
            {
                MessageBox.Show("Выберите клиента для редактирования.");
            }
        }
        private void DeleteButton_Click(object sender, RoutedEventArgs e)
        {
            if (ClientListView.SelectedItem is Client SC)
            {
                Clients.Remove(SC);
            }
            else
            {
                MessageBox.Show("Выберите клиента для удаления.");
            }
        }
    }
}