﻿using System.Collections.ObjectModel;
using System.Windows;
using System.Windows.Input;

namespace X
{
    public class MainViewModel
    {
        public ObservableCollection<Client> Clients { get; set; }
        public Client SelectedClient { get; set; }
        public ICommand AddCommand { get; }
        public ICommand EditCommand { get; }
        public ICommand DeleteCommand { get; }
        public MainViewModel()
        {
            Clients = new ObservableCollection<Client>
            {
                new Client { Name = "Ангелина Авдеева", Contact = "+37529. . . . . . .", Email = "ghostetowninmymind@mail.com", Type = "VIP" },
                new Client { Name = "Имя Фамилия", Contact = "+3752912345679", Email = "name@mail.com", Type = "Обычный" }
            };
            AddCommand = new RelayCommand(AddClient);
            EditCommand = new RelayCommand(EditClient, CanEditOrDelete);
            DeleteCommand = new RelayCommand(DeleteClient, CanEditOrDelete);
        }
        private void AddClient(object param)
        {
            var f = new ClientFormWindow();
            if (f.ShowDialog() == true)
            {
                Clients.Add(f.Client);
            }
        }
        private void EditClient(object param)
        {
            if (SelectedClient != null)
            {
                Client t = new Client
                {
                    Name = SelectedClient.Name,
                    Contact = SelectedClient.Contact,
                    Email = SelectedClient.Email,
                    Type = SelectedClient.Type
                };
                var f = new ClientFormWindow(t);
                if (f.ShowDialog() == true)
                {
                    SelectedClient.Name = t.Name;
                    SelectedClient.Contact = t.Contact;
                    SelectedClient.Email = t.Email;
                    SelectedClient.Type = t.Type;
                }
            }
        }
        private void DeleteClient(object param)
        {
            if (SelectedClient != null)
            {
                if (MessageBox.Show($"Удалить клиента {SelectedClient.Name}?", "Подтверждение", MessageBoxButton.YesNo) == MessageBoxResult.Yes)
                {
                    Clients.Remove(SelectedClient);
                }
            }
        }
        private bool CanEditOrDelete(object param) => SelectedClient != null;
    }
}