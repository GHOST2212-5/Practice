﻿using System.Windows;

namespace X
{
    public partial class ClientFormWindow : Window
    {
        public Client Client { get; private set; }
        /// <summary>Фиксированный список типов клиентов.</summary>
        public string[] Types { get; } = { "VIP", "Обычный" };
        public ClientFormWindow(Client client = null)
        {
            InitializeComponent();
            Client = client ?? new Client();
            DataContext = this;
        }
        private void SaveButton_Click(object sender, RoutedEventArgs e)
        {
            DialogResult = true;
            Close();
        }
        private void CancelButton_Click(object sender, RoutedEventArgs e)
        {
            DialogResult = false;
            Close();
        }
    }
}