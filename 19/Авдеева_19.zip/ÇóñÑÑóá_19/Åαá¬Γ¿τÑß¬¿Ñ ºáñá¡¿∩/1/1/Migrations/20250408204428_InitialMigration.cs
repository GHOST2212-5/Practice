﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace _1.Migrations
{
    public partial class InitialMigration : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "Clients",
                columns: table => new
                {
                    Id = table.Column<int>(nullable: false)
                        .Annotation("Sqlite:Autoincrement", true),
                    Name = table.Column<string>(nullable: false),
                    Contact = table.Column<string>(nullable: false),
                    Email = table.Column<string>(nullable: false),
                    Type = table.Column<string>(nullable: false),
                    DealsDescription = table.Column<string>(nullable: true),
                    IsActive = table.Column<bool>(nullable: false, defaultValue: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Clients", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "Orders",
                columns: table => new
                {
                    OrderId = table.Column<int>(nullable: false)
                        .Annotation("Sqlite:Autoincrement", true),
                    ClientName = table.Column<string>(nullable: false),
                    ClientModelId = table.Column<int>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Orders", x => x.OrderId);
                    table.ForeignKey(
                        name: "FK_Orders_Clients_ClientModelId",
                        column: x => x.ClientModelId,
                        principalTable: "Clients",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.InsertData(
                table: "Clients",
                columns: new[] { "Id", "Contact", "DealsDescription", "Email", "IsActive", "Name", "Type" },
                values: new object[] { 1, "+37529. . . . . . .", "Постоянный клиент с особыми условиями.", "angelina@mail.com", true, "Ангелина Авдеева", "VIP" });

            migrationBuilder.InsertData(
                table: "Clients",
                columns: new[] { "Id", "Contact", "DealsDescription", "Email", "Name", "Type" },
                values: new object[] { 2, "+3752912345679", "Недавний клиент без особенностей.", "name@mail.com", "Имя Фамилия", "Обычный" });

            migrationBuilder.InsertData(
                table: "Orders",
                columns: new[] { "OrderId", "ClientModelId", "ClientName" },
                values: new object[] { 1, null, "Ангелина Авдеева" });

            migrationBuilder.InsertData(
                table: "Orders",
                columns: new[] { "OrderId", "ClientModelId", "ClientName" },
                values: new object[] { 2, null, "Имя Фамилия" });

            migrationBuilder.CreateIndex(
                name: "IX_Orders_ClientModelId",
                table: "Orders",
                column: "ClientModelId");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "Orders");

            migrationBuilder.DropTable(
                name: "Clients");
        }
    }
}
