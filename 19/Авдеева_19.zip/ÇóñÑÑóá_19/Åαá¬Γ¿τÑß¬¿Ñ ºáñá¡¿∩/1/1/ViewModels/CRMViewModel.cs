﻿using _1;
using System;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using X.Models;
using X.Services;
using X.Views;

namespace X.ViewModels
{
    public class CRMViewModel : INotifyPropertyChanged
    {
        private readonly ClientRepository clientRepository;
        private bool isLoading;
        private ClientModel selectedClient;

        public ObservableCollection<ClientModel> Clients { get; private set; } = new();
        public bool IsLoading
        {
            get => isLoading;
            set { isLoading = value; OnPropertyChanged(nameof(IsLoading)); }
        }
        public ClientModel SelectedClient
        {
            get => selectedClient;
            set
            {
                selectedClient = value;
                OnPropertyChanged(nameof(SelectedClient));
                CommandManager.InvalidateRequerySuggested();
            }
        }
        public ICommand AddCommand { get; }
        public ICommand EditCommand { get; }
        public ICommand DeleteCommand { get; }
        public ICommand LoadCommand { get; }

        public CRMViewModel(ClientRepository repository)
        {
            clientRepository = repository;
            AddCommand = new RelayCommand(AddClient);
            EditCommand = new RelayCommand(EditClient, CanEditOrDelete);
            DeleteCommand = new RelayCommand(DeleteClient, CanEditOrDelete);
            LoadCommand = new RelayCommand(async (obj) => await LoadDataAsync(), param => true);

            _ = LoadDataAsync();
        }

        private async Task LoadDataAsync()
        {
            IsLoading = true;

            try
            {
                var clients = await clientRepository.GetAllClientsAsync();
                if (clients == null || clients.Count == 0)
                {
                    MessageBox.Show("Нет данных в таблице Clients!", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                    return;
                }

                App.Current.Dispatcher.Invoke(() =>
                {
                    Clients.Clear();
                    foreach (var client in clients)
                    {
                        Clients.Add(client);
                    }
                });
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка загрузки данных: {ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
            finally
            {
                IsLoading = false;
            }
        }
        private void AddClient(object param)
        {
            var form = new ClientFormWindow();
            if (form.ShowDialog() == true)
            {
                var newClient = form.Client;

                Task.Run(async () =>
                {
                    await clientRepository.AddClientAsync(newClient);
                    App.Current.Dispatcher.Invoke(() => Clients.Add(newClient));
                });
            }
        }
        private void EditClient(object param)
        {
            if (SelectedClient != null)
            {
                var updatedClient = new ClientModel
                {
                    Id = SelectedClient.Id,
                    Name = SelectedClient.Name,
                    Contact = SelectedClient.Contact,
                    Email = SelectedClient.Email,
                    Type = SelectedClient.Type,
                    DealsDescription = SelectedClient.DealsDescription,
                    IsActive = SelectedClient.IsActive
                };

                var form = new ClientFormWindow(updatedClient);
                if (form.ShowDialog() == true)
                {
                    Task.Run(async () =>
                    {
                        await clientRepository.UpdateClientAsync(updatedClient);
                        App.Current.Dispatcher.Invoke(() =>
                        {
                            var index = Clients.IndexOf(SelectedClient);
                            Clients[index] = updatedClient;
                        });
                    });
                }
            }
        }
        private void DeleteClient(object param)
        {
            if (SelectedClient != null)
            {
                var result = MessageBox.Show(
                    $"Вы уверены, что хотите удалить клиента \"{SelectedClient.Name}\"?",
                    "Подтверждение удаления",
                    MessageBoxButton.YesNo,
                    MessageBoxImage.Question);

                if (result == MessageBoxResult.Yes)
                {
                    Task.Run(async () =>
                    {
                        await clientRepository.DeleteClientAsync(SelectedClient);
                        App.Current.Dispatcher.Invoke(() => Clients.Remove(SelectedClient));
                    });
                }
            }
        }
        private bool CanEditOrDelete(object param) => SelectedClient != null;

        public event PropertyChangedEventHandler PropertyChanged;
        protected void OnPropertyChanged(string propertyName)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
    }
}