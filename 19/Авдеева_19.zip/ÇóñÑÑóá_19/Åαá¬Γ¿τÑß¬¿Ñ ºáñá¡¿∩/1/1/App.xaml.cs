﻿using Microsoft.Data.Sqlite;
using Microsoft.Extensions.Configuration;
using System;
using System.Windows;
using X.Services;
using X.ViewModels;
using X.Views;


namespace _1
{
    public partial class App : Application
    {
        private readonly UserManager userManager;

        public App()
        {
            userManager = new UserManager();
        }

        [STAThread]
        public static void Main()
        {
            var app = new App();
            app.InitializeComponent();
            app.Run();
        }

        protected override async void OnStartup(StartupEventArgs e)
        {
            base.OnStartup(e);
            try
            {
                var loginWindow = new LoginWindow(userManager);
                loginWindow.ShowDialog();

                if (loginWindow.IsAuthenticated)
                {
                    var context = new DesignTimeDbContextFactory().CreateDbContext([]);
                    var clientRepository = new ClientRepository(context);

                    var clients = await clientRepository.GetActiveClientsAsync();
                    var crmViewModel = new CRMViewModel(clientRepository);

                    var mainWindow = new MainWindow(crmViewModel);
                    Current.MainWindow = mainWindow;
                    mainWindow.Show();
                    loginWindow.Close();
                }
                else
                {
                    Shutdown();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка запуска: {ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                Shutdown();
            }
        }
    }
}