﻿using System.Collections.Generic;
using System.Threading.Tasks;
using X.Models;

namespace X.Services
{
    public class ClientService
    {
        public async Task<List<ClientModel>> GetClientsAsync()
        {
            return await Task.Run(() => new List<ClientModel>
            {
                new ClientModel { Name = "Ангелина Авдеева", Contact = "+37529. . . . . . .", Email = "angelina@mail.com", Type = "VIP" },
                new ClientModel { Name = "Имя Фамилия", Contact = "+3752912345679", Email = "name@mail.com", Type = "Обычный" }
            });
        }
    }
}