﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using X.Models;

namespace X.Services
{
    public class ClientRepository
    {
        private readonly CRMContext dbContext;

        public ClientRepository(CRMContext context)
        {
            dbContext = context;
        }

        public async Task<List<ClientModel>> GetAllClientsAsync()
        {
            var clients = await dbContext.Clients.ToListAsync();
            if (clients == null || !clients.Any())
            {
                throw new Exception("Данные клиентов отсутствуют в базе.");
            }
            return clients;
        }

        public async Task<List<ClientModel>> GetActiveClientsAsync()
        {
            return await dbContext.Clients.Where(c => c.IsActive).ToListAsync();
        }

        public async Task AddClientAsync(ClientModel client)
        {
            dbContext.Clients.Add(client);
            await dbContext.SaveChangesAsync();
        }

        public async Task UpdateClientAsync(ClientModel client)
        {
            dbContext.Clients.Update(client);
            await dbContext.SaveChangesAsync();
        }
        public async Task DeleteClientAsync(ClientModel client)
        {
            dbContext.Clients.Remove(client);
            await dbContext.SaveChangesAsync();
        }
    }
}