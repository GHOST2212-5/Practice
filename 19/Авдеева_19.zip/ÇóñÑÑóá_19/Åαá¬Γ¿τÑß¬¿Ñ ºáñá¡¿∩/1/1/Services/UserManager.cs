﻿using System.Collections.Generic;
using System.IO;
using Newtonsoft.Json;
using BCrypt.Net;
using X.Models;

namespace X.Services
{
    public class UserManager
    {
        private const string FilePath = "users.json";
        private List<UserModel> _users = new List<UserModel>();
        public UserManager()
        {
            LoadUsers();
        }
        private void LoadUsers()
        {
            if (File.Exists(FilePath))
            {
                var json = File.ReadAllText(FilePath);
                _users = JsonConvert.DeserializeObject<List<UserModel>>(json) ?? new List<UserModel>();
            }
            else
            {
                _users = new List<UserModel>
                {
                    new UserModel
                    {
                        Username = "Angelina",
                        PasswordHash = BCrypt.Net.BCrypt.HashPassword("password"), // пароль 22122005
                        Role = "Administrator"
                    }
                };
                SaveUsers();
            }
        }
        public void SaveUsers()
        {
            var json = JsonConvert.SerializeObject(_users, Newtonsoft.Json.Formatting.Indented);
            File.WriteAllText(FilePath, json);
        }
        public bool RegisterUser(string username, string password, string role)
        {
            if (_users.Exists(u => u.Username == username))
                return false;
            _users.Add(new UserModel
            {
                Username = username,
                PasswordHash = BCrypt.Net.BCrypt.HashPassword(password),
                Role = role
            });
            SaveUsers();
            return true;
        }
        public bool Authenticate(string username, string password)
        {
            var user = _users.Find(u => u.Username == username);
            return user != null && BCrypt.Net.BCrypt.Verify(password, user.PasswordHash);
        }
        public UserModel GetUser(string username)
        {
            return _users.Find(u => u.Username == username);
        }
    }
}