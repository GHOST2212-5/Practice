﻿using Microsoft.EntityFrameworkCore;
using X.Models;

namespace X.Services
{
    public class CRMContext : DbContext
    {
        public DbSet<ClientModel> Clients { get; set; }
        public DbSet<OrderModel> Orders { get; set; }

        public CRMContext(DbContextOptions<CRMContext> options) : base(options) { }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
                optionsBuilder.UseSqlite("Data Source=crm.db");
            }
        }
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            modelBuilder.Entity<ClientModel>().HasKey(c => c.Id);
            modelBuilder.Entity<ClientModel>().Property(c => c.Name).IsRequired();
            modelBuilder.Entity<ClientModel>().Property(c => c.Contact).IsRequired();
            modelBuilder.Entity<ClientModel>().Property(c => c.Email).IsRequired();
            modelBuilder.Entity<ClientModel>().Property(c => c.Type).IsRequired();
            modelBuilder.Entity<ClientModel>().Property(c => c.DealsDescription).IsRequired(false);
            modelBuilder.Entity<ClientModel>().Property(c => c.IsActive).HasDefaultValue(true);

            modelBuilder.Entity<OrderModel>().HasKey(o => o.OrderId);
            modelBuilder.Entity<OrderModel>().Property(o => o.ClientName).IsRequired();
            modelBuilder.Entity<OrderModel>()
                .HasOne<ClientModel>()
                .WithMany(c => c.Orders)
                .HasForeignKey("ClientModelId");

            modelBuilder.Entity<ClientModel>().HasData(
                new ClientModel
                {
                    Id = 1,
                    Name = "Ангелина Авдеева",
                    Contact = "+37529. . . . . . .",
                    Email = "angelina@mail.com",
                    Type = "VIP",
                    DealsDescription = "Постоянный клиент с особыми условиями.",
                    IsActive = true
                },
                new ClientModel
                {
                    Id = 2,
                    Name = "Имя Фамилия",
                    Contact = "+3752912345679",
                    Email = "name@mail.com",
                    Type = "Обычный",
                    DealsDescription = "Недавний клиент без особенностей.",
                    IsActive = false
                }
            );

            modelBuilder.Entity<OrderModel>().HasData(
                new OrderModel
                {
                    OrderId = 1,
                    ClientName = "Ангелина Авдеева"
                },
                new OrderModel
                {
                    OrderId = 2,
                    ClientName = "Имя Фамилия"
                }
            );
        }
    }
}