﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Design;

namespace X.Services
{
    public class DesignTimeDbContextFactory : IDesignTimeDbContextFactory<CRMContext>
    {
        public CRMContext CreateDbContext(string[] args)
        {
            var optionsBuilder = new DbContextOptionsBuilder<CRMContext>();
            optionsBuilder.UseSqlite("crmConnection");
            //optionsBuilder.UseSqlite("Data Source=crm.db");

            return new CRMContext(optionsBuilder.Options);
        }
    }
}