﻿using System;
using System.Windows.Input;

namespace X
{
    public class RelayCommand : ICommand
    {
        private readonly Action<object> ec;
        private readonly Predicate<object> ce;

        public RelayCommand(Action<object> execute, Predicate<object> canExecute = null)
        {
            ec = execute ?? throw new ArgumentNullException(nameof(execute));
            ce = canExecute;
        }

        public bool CanExecute(object param) => ce?.Invoke(param) ?? true;
        public void Execute(object param) => ec(param);
        public event EventHandler CanExecuteChanged
        {
            add => CommandManager.RequerySuggested += value;
            remove => CommandManager.RequerySuggested -= value;
        }
    }
}