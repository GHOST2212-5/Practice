﻿using System.Collections.Generic;
using System.Windows;
using X.Models;

namespace X.Views
{
    public partial class ClientFormWindow : Window
    {
        public ClientModel Client { get; private set; }
        public List<string> Types { get; } = new() { "Обычный", "VIP" };

        public ClientFormWindow()
        {
            InitializeComponent();
            Client = new ClientModel();
            DataContext = this;
        }

        public ClientFormWindow(ClientModel client) : this()
        {
            Client = client;
            DataContext = this;
        }

        private void SaveButton_Click(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(Client.Name) ||
                string.IsNullOrWhiteSpace(Client.Contact) ||
                string.IsNullOrWhiteSpace(Client.Email) ||
                string.IsNullOrWhiteSpace(Client.Type))
            {
                MessageBox.Show("Все поля обязательны для заполнения!", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            DialogResult = true;
            Close();
        }

        private void CancelButton_Click(object sender, RoutedEventArgs e)
        {
            DialogResult = false;
            Close();
        }
    }

}
