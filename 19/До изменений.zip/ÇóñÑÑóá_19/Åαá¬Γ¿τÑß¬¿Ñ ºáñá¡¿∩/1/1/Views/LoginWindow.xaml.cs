﻿using System.Windows;
using X.Services;

namespace X.Views
{
    public partial class LoginWindow : Window
    {
        private readonly UserManager userManager;

        public bool IsAuthenticated { get; private set; } = false;

        public LoginWindow(UserManager userManager)
        {
            InitializeComponent();
            this.userManager = userManager;
            IsAuthenticated = false;
        }

        private void OnLoginClick(object sender, RoutedEventArgs e)
        {
            string username = UsernameTextBox.Text;
            string password = PasswordBox.Password;

            if (userManager.Authenticate(username, password))
            {
                IsAuthenticated = true;
                Hide();
            }
            else
            {
                MessageBox.Show("Неверные данные! Проверьте логин и пароль.", "Ошибка авторизации", MessageBoxButton.OK, MessageBoxImage.Warning);
            }
        }
    }
}
