﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Design;
using Microsoft.Extensions.DependencyInjection;

namespace X.Services
{
    public class DesignTimeDbContextFactory : IDesignTimeDbContextFactory<CRMContext>
    {
        public CRMContext CreateDbContext(string[] args)
        {
            var optionsBuilder = new DbContextOptionsBuilder<CRMContext>();
            optionsBuilder.UseSqlite("Data Source=crm.db");

            return new CRMContext(optionsBuilder.Options);
        }
    }
}