﻿using System.ComponentModel;
using System.ComponentModel.DataAnnotations;

namespace X.Models
{
    public class OrderModel : INotifyPropertyChanged
    {
        [Key]
        public int OrderId { get; set; }

        private string clientName;

        public string ClientName
        {
            get => clientName;
            set { clientName = value; OnPropertyChanged(nameof(ClientName)); }
        }

        public event PropertyChangedEventHandler PropertyChanged;
        protected void OnPropertyChanged(string pn)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(pn));
        }
    }
}