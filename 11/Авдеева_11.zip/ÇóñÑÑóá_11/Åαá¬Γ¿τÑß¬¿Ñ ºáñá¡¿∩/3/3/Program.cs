﻿using System;
using System.Collections.Generic;

namespace E
{
    /// <summary>Интерфейс подписчика. Любой класс, чтобы получать увед-я об изменениях цены акций, должен реализовать этот интерфейс.</summary>
    public interface IStockObserver
    {
        /// <summary>Метод для получения тех самых уведомления.</summary>
        /// <param name="s">Символ акции(СА).</param> <param name="p">Новая цена акции(НЦА).</param>
        void Update(string s, decimal p);
    }
    /// <summary>Издатель представляет биржевой рынок, хранит подписчиков и уведомляет их.</summary>
    public class StockMarket
    {
        private readonly List<IStockObserver> _os = new List<IStockObserver>();
        /// <summary>Подписывает нового наблюдателя(инвестора).</summary>
        /// <param name="o">Объект, реализующий IStockObserver.</param>
        public void Attach(IStockObserver o)
        {
            if (o == null)
            {
                throw new ArgumentNullException(nameof(o));
            }

            if (!_os.Contains(o))
            {
                _os.Add(o);
            }
        }
        /// <summary>Отписывает наблюдателя.</summary>
        /// <param name="o">...</param>
        public void Detach(IStockObserver o)
        {
            if (o == null)
            {
                throw new ArgumentNullException(nameof(o));
            }
            _os.Remove(o);
        }
        /// <summary>Уведомляет всех подписчиков об изменении цены указанной акции.</summary>
        /// <param name="s">СА.</param> <param name="p">НЦА.</param>
        public void Notify(string s, decimal p)
        {
            foreach (var o in _os)
            {
                o.Update(s, p);
            }
        }
        /// <summary>Изменяет цену акции и уведомляет подписчиков.</summary>
        /// <param name="s">СА.</param> <param name="p">НЦА.</param>
        public void ChangeStockPrice(string s, decimal p)
        {
            Console.WriteLine($"Цена акции {s} изменилась, текущая стоимость равна {p}.");
            Notify(s, p);
            Console.WriteLine();
        }
    }
    /// <summary>Подписчик-инвестор, получает уведомления об изменениях.</summary>
    public class Investor : IStockObserver
    {
        public string Name { get; }

        /// <summary>Экземпляр инвестора.</summary>
        /// <param name="n">Имя инвестора.</param>
        public Investor(string n)
        {
            Name = n;
        }
        /// <summary>Реализация получения уведомления, инвестор выводит инф. на консоль.</summary>
        /// <param name="s">СА.</param> <param name="p">НЦА.</param>
        public void Update(string s, decimal p)
        {
            Console.WriteLine($"Инвестор {Name} получил уведомление: акция {s} теперь стоит {p}");
        }
    }

    public class SM
    {
        public static void Main(string[] args)
        {
            var m = new StockMarket();
            var i1 = new Investor("Ангелина");
            var i2 = new Investor("Артём");

            m.Attach(i1);
            m.Attach(i2);
            m.ChangeStockPrice("A", 100.00m);
            m.ChangeStockPrice("B", 222.22m);
            m.Detach(i1);
            m.ChangeStockPrice("C", 666.00m);
        }
    }
}