﻿using System;
using System.Collections.Generic;

namespace E
{
    /// <summary>ConfigManager реализует Singleton и хранит настройки. Экземпляр класса доступен из любой части программы через Instance.</summary>
    public sealed class ConfigManager
    {
        // Ленивая :) инициализация ConfigManager. Lazy<T> - безопасная иниц-я в многопоточной среде
        private static readonly Lazy<ConfigManager> _ic =
            new Lazy<ConfigManager>(() => new ConfigManager());
        // Словарь для настроек ("ключ-знач.")
        private readonly Dictionary<string, string> _confs = new Dictionary<string, string>();
        // Приватный конструктор не дает созд. экземпляры извне
        private ConfigManager()
        {
        }
        /// <summary>Единств-я глоб. точка доступа к ConfigManager.</summary>
        public static ConfigManager С => _ic.Value;
        /// <summary>Задаёт значение настройки(ЗН) по указанному ключу(УК). Ключ существует - значение обновляется.</summary>
        /// <param name="key">Ключ настройки(КН).</param> <param name="value">ЗН.</param>
        /// <exception cref="ArgumentException">Выбрасывается, когда ключ пустой or null.</exception>
        public void SetConfig(string key, string value)
        {
            if (string.IsNullOrEmpty(key))
            {
                throw new ArgumentException("Ключ не может быть пустым.", nameof(key));
            }
            _confs[key] = value;
        }
        /// <summary>Получает знач. настройки по УК. Отсутствие ключа - null.</summary>
        /// <param name="key">КН.</param>
        /// <returns>ЗН или null.</returns>
        /// <exception cref="ArgumentException">Как и прошлый.</exception>
        public string GetConfig(string key)
        {
            if (string.IsNullOrEmpty(key))
            {
                throw new ArgumentException("Ключ не может быть пустым.", nameof(key));
            }
            return _confs.TryGetValue(key, out string value) ? value : null;
        }
    }
    class S
    {
        public static void Main(string[] args)
        {
            ConfigManager conf = ConfigManager.С;
            conf.SetConfig("PracticalAssignment", "1.");

            string? a = conf.GetConfig("PracticalAssignment");
            Console.WriteLine($"Practical Assignment: {a}");
        }
    }
}