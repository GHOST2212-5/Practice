﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace E
{
    public class DataFilterProduct
    {
        private readonly List<IFilterStrategy> _fs = new List<IFilterStrategy>();
        public void AddFilter(IFilterStrategy f)
        {
            if (f != null)
            {
                _fs.Add(f);
            }
        }
        public IEnumerable<int> FilterData(IEnumerable<int> d)
        {
            IEnumerable<int> r = d;
            foreach (var f in _fs)
            {
                r = f.Filter(r);
            }
            return r;
        }
    }
    public interface IFilterStrategy
    {
        IEnumerable<int> Filter(IEnumerable<int> d);
    }
    public class EvenNumberFilter : IFilterStrategy
    {
        public IEnumerable<int> Filter(IEnumerable<int> d)
        {
            return d.Where(n => n % 2 == 0);
        }
    }
    public class PrimeNumberFilter : IFilterStrategy
    {
        public IEnumerable<int> Filter(IEnumerable<int> d)
        {
            return d.Where(IsPrime);
        }
        private bool IsPrime(int num)
        {
            if (num < 2)
            {
                return false;
            }
            for (int i = 2; i <= Math.Sqrt(num); i++)
            {
                if (num % i == 0)
                {
                    return false;
                }
            }
            return true;
        }
    }
    public class RangeFilter : IFilterStrategy
    {
        public int Min { get; }
        public int Max { get; }

        public RangeFilter(int min, int max)
        {
            Min = min;
            Max = max;
        }
        public IEnumerable<int> Filter(IEnumerable<int> d)
        {
            return d.Where(n => n >= Min && n <= Max);
        }
    }
    public interface IDataFilterBuilder
    {
        void Reset();
        void AddEvenNumberFilter();
        void AddPrimeNumberFilter();
        void AddRangeFilter(int min, int max);
        DataFilterProduct GetResult();
    }
    public class DataFilterBuilder : IDataFilterBuilder
    {
        private DataFilterProduct _p = new DataFilterProduct();
        public void Reset()
        {
            _p = new DataFilterProduct();
        }
        public void AddEvenNumberFilter()
        {
            _p.AddFilter(new EvenNumberFilter());
        }
        public void AddPrimeNumberFilter()
        {
            _p.AddFilter(new PrimeNumberFilter());
        }
        public void AddRangeFilter(int min, int max)
        {
            _p.AddFilter(new RangeFilter(min, max));
        }
        public DataFilterProduct GetResult() => _p;
    }
    public class DataFilterDirector
    {
        private readonly IDataFilterBuilder _b;
        public DataFilterDirector(IDataFilterBuilder b)
        {
            _b = b;
        }
        public void BuildEvenAndRangeFilter(int min, int max)
        {
            _b.Reset();
            _b.AddEvenNumberFilter();
            _b.AddRangeFilter(min, max);
        }
        public void BuildAllFilters(int min, int max)
        {
            _b.Reset();
            _b.AddEvenNumberFilter();
            _b.AddPrimeNumberFilter();
            _b.AddRangeFilter(min, max);
        }
    }

    public class Sl
    {
        public static void Main(string[] args)
        {
            var nums = Enumerable.Range(1, 100).ToList();
            IDataFilterBuilder b = new DataFilterBuilder();
            var dr = new DataFilterDirector(b);

            dr.BuildAllFilters(2, 10);
            DataFilterProduct p = b.GetResult();
            var N = p.FilterData(nums);
            Console.WriteLine("Результат фильтрации по всем фильтрам:");
            Console.WriteLine(string.Join(", ", N));

            dr.BuildEvenAndRangeFilter(20, 80);
            p = b.GetResult();
            N = p.FilterData(nums);
            Console.WriteLine("\nРезультат фильтрации (чётные, от 20 по 80):");
            Console.WriteLine(string.Join(", ", N));
        }
    }
}
