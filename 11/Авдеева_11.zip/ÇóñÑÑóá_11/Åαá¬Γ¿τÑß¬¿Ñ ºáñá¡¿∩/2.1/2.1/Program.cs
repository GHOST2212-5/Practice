﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace E
{
    public interface IFilterStrategy
    {
        IEnumerable<int> Filter(IEnumerable<int> d);
    }
    public class EvenNumberFilter : IFilterStrategy
    {
        public IEnumerable<int> Filter(IEnumerable<int> d)
        {
            return d.Where(n => n % 2 == 0);
        }
    }
    public class PrimeNumberFilter : IFilterStrategy
    {
        public IEnumerable<int> Filter(IEnumerable<int> d)
        {
            return d.Where(IsPrime);
        }
        private bool IsPrime(int num)
        {
            if (num < 2)
            {
                return false;
            }
            for (int i = 2; i <= Math.Sqrt(num); i++)
            {
                if (num % i == 0)
                {
                    return false;
                }
            }
            return true;
        }
    }
    public class RangeFilter : IFilterStrategy
    {
        public int Min { get; }
        public int Max { get; }
        public RangeFilter(int min, int max)
        {
            Min = min;
            Max = max;
        }
        public IEnumerable<int> Filter(IEnumerable<int> d)
        {
            return d.Where(n => n >= Min && n <= Max);
        }
    }
    public class DataFilter
    {
        private IFilterStrategy _s;
        public DataFilter(IFilterStrategy s)
        {
            _s = s;
        }
        public void SetStrategy(IFilterStrategy s)
        {
            _s = s;
        }
        public IEnumerable<int> FilterData(IEnumerable<int> d)
        {
            return _s.Filter(d);
        }
    }

    public class St
    {
        public static void Main(string[] args)
        {
            var nums = Enumerable.Range(1, 50).ToList();
            var f = new DataFilter(new EvenNumberFilter());

            Console.WriteLine("Чётные числа:");
            Console.WriteLine(string.Join(", ", f.FilterData(nums)));
            f.SetStrategy(new PrimeNumberFilter());
            Console.WriteLine("\nПростые числа:");
            Console.WriteLine(string.Join(", ", f.FilterData(nums)));
            f.SetStrategy(new RangeFilter(10, 20));
            Console.WriteLine("\nЧисла от 10 до 20:");
            Console.WriteLine(string.Join(", ", f.FilterData(nums)));
        }
    }
}
