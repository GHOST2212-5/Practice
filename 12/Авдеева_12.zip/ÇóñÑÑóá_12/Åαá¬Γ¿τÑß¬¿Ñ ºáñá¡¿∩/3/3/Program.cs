﻿using System;

namespace E
{
    public interface ICommand
    {
        void Execute();
    }
    public class RobotVacuum
    {
        public void StartCleaning()
        {
            Console.WriteLine("Робот-пылесос начинает уборку...");
        }
        public void StopCleaning()
        {
            Console.WriteLine("Робот-пылесос останавливает уборку.");
        }
        public void ReturnToBase()
        {
            Console.WriteLine("Робот-пылесос возвращается на базу...");
        }
    }
    public class StartCleaningCommand : ICommand
    {
        private readonly RobotVacuum _r;
        public StartCleaningCommand(RobotVacuum r)
        {
            _r = r ?? throw new ArgumentNullException(nameof(r));
        }
        public void Execute()
        {
            _r.StartCleaning();
        }
    }
    public class StopCleaningCommand : ICommand
    {
        private readonly RobotVacuum _r;
        public StopCleaningCommand(RobotVacuum r)
        {
            _r = r ?? throw new ArgumentNullException(nameof(r));
        }
        public void Execute()
        {
            _r.StopCleaning();
        }
    }
    public class ReturnToBaseCommand : ICommand
    {
        private readonly RobotVacuum _r;
        public ReturnToBaseCommand(RobotVacuum r)
        {
            _r = r ?? throw new ArgumentNullException(nameof(r));
        }
        public void Execute()
        {
            _r.ReturnToBase();
        }
    }
    public class RobotController
    {
        private ICommand? _c;

        public void SetCommand(ICommand c)
        {
            _c = c ?? throw new ArgumentNullException(nameof(c));
        }

        public void ExecuteCommand()
        {
            _c?.Execute();
        }
    }

    public class R
    {
        public static void Main(string[] args)
        {
            var r = new RobotVacuum();
            var l = new RobotController();
            var t = new StartCleaningCommand(r);
            var p = new StopCleaningCommand(r);
            var rn = new ReturnToBaseCommand(r);

            l.SetCommand(t);
            l.ExecuteCommand();
            l.SetCommand(p);
            l.ExecuteCommand();
            l.SetCommand(rn);
            l.ExecuteCommand();
        }
    }
}