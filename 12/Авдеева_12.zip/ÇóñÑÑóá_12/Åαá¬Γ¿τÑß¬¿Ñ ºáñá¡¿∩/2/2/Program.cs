﻿using System;

namespace E
{
    public interface ICoffee
    {
        string GetDescription();
        double GetCost();
    }
    public class BasicCoffee : ICoffee
    {
        public string GetDescription()
        {
            return "Чёрный кофе";
        }
        public double GetCost()
        {
            return 50.00;
        }
    }
    public abstract class CoffeeDecorator : ICoffee
    {
        protected ICoffee _c;
        public CoffeeDecorator(ICoffee c)
        {
            _c = c ?? throw new ArgumentNullException(nameof(c));
        }
        public virtual string GetDescription()
        {
            return _c.GetDescription();
        }
        public virtual double GetCost()
        {
            return _c.GetCost();
        }
    }
    public class MilkDecorator : CoffeeDecorator
    {
        public MilkDecorator(ICoffee c) : base(c) { }
        public override string GetDescription()
        {
            return _c.GetDescription() + " с молоком";
        }
        public override double GetCost()
        {
            return _c.GetCost() + 10.00;
        }
    }
    public class SugarDecorator : CoffeeDecorator
    {
        public SugarDecorator(ICoffee c) : base(c) { }
        public override string GetDescription()
        {
            return _c.GetDescription() + ", сахаром";
        }
        public override double GetCost()
        {
            return _c.GetCost() + 5.00;
        }
    }
    public class SyrupDecorator : CoffeeDecorator
    {
        public SyrupDecorator(ICoffee c) : base(c) { }
        public override string GetDescription()
        {
            return _c.GetDescription() + " и ванильным сиропом";
        }
        public override double GetCost()
        {
            return _c.GetCost() + 15.00;
        }
    }

    public class C
    {
        public static void Main(string[] args)
        {
            ICoffee c = new BasicCoffee();

            Console.WriteLine($"Позиция: {c.GetDescription()} | Стоимость: {c.GetCost()}");
            c = new MilkDecorator(c);
            Console.WriteLine($"Позиция: {c.GetDescription()} | Стоимость: {c.GetCost()}");
            c = new SugarDecorator(c);
            Console.WriteLine($"Позиция: {c.GetDescription()} | Стоимость: {c.GetCost()}");
            c = new SyrupDecorator(c);
            Console.WriteLine($"Позиция: {c.GetDescription()} | Стоимость: {c.GetCost()}");
        }
    }
}