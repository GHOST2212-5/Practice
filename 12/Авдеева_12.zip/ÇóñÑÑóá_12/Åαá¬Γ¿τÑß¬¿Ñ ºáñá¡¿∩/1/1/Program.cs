﻿using System;

namespace E
{
    /// <summary>Интерфейс карты.</summary>
    public interface IBankCard
    {
        void Use();
    }
    /// <summary>Кредитная карта.</summary>
    public class CreditCard : IBankCard
    {
        public void Use()
        {
            Console.WriteLine("В наличии кредитная карта.");
        }
    }
    /// <summary>Дебетовая карта.</summary>
    public class DebitCard : IBankCard
    {
        public void Use()
        {
            Console.WriteLine("В наличии дебетовая карта.");
        }
    }
    /// <summary>Виртуальная карта.</summary>
    public class VirtualCard : IBankCard
    {
        public void Use()
        {
            Console.WriteLine("В наличии виртуальная карта.");
        }
    }
    public abstract class BankCardFactory
    {
        public abstract IBankCard CreateCard();
    }
    /// <summary>Фабрика кредитных карт.</summary>
    public class CreditCardFactory : BankCardFactory
    {
        public override IBankCard CreateCard()
        {
            return new CreditCard();
        }
    }
    /// <summary>Фабрика дебетовых карт.</summary>
    public class DebitCardFactory : BankCardFactory
    {
        public override IBankCard CreateCard()
        {
            return new DebitCard();
        }
    }
    /// <summary>Фабрика виртуальных карт.</summary>
    public class VirtualCardFactory : BankCardFactory
    {
        public override IBankCard CreateCard()
        {
            return new VirtualCard();
        }
    }

    public class C
    {
        public static void Main(string[] args)
        {
            BankCardFactory c = new CreditCardFactory();
            BankCardFactory d = new DebitCardFactory();
            BankCardFactory v = new VirtualCardFactory();

            IBankCard creditCard = c.CreateCard();
            creditCard.Use();
            IBankCard debitCard = d.CreateCard();
            debitCard.Use();
            IBankCard virtualCard = v.CreateCard();
            virtualCard.Use();
        }
    }
}