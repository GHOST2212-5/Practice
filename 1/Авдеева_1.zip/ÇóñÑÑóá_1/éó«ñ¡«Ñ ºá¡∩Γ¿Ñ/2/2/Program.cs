﻿using System;

class TN
{
    static void Main()
    {
        Console.Write("Введите двузначное число: ");
        int num = Convert.ToInt32(Console.ReadLine());

        int ts = num / 10; // десятки
        int os = num % 10; // единицы
        int prod = ts * os;

        Console.WriteLine("Произведение цифр числа: {0}", prod);
    }
}
