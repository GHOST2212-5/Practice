﻿using System;

class TF
{
    static void Main()
    {
        Console.Write("Введите угол: ");
        double degs = Convert.ToDouble(Console.ReadLine());
        double rads = degs * Math.PI / 180;

        double z1 = (1 - 2 * Math.Pow(Math.Sin(rads), 2)) / (1 + Math.Sin(2 * rads));
        double z2 = (1 - Math.Tan(rads)) / (1 + Math.Tan(rads));

        Console.WriteLine("Результат z1: {0}", Math.Round(z1, 6));
        Console.WriteLine("Результат z2: {0}", Math.Round(z2, 6));

        Console.WriteLine("Результаты совпадают - {0}", Math.Abs(z1 - z2) < 0.000001);
    }
}
