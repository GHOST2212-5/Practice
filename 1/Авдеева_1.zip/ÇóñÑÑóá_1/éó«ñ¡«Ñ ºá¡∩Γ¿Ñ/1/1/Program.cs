﻿using System;

class Cylinder
{
    static void Main()
    {
        Console.Write("Введите радиус основания (см): ");
        double r = Convert.ToDouble(Console.ReadLine());

        Console.Write("Введите высоту (см): ");
        double h = Convert.ToDouble(Console.ReadLine());

        double v = Math.PI * r * r * h;

        Console.WriteLine("Объем цилиндра: {0} куб. см.", Math.Round(v, 2));
    }
}
