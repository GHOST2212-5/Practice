﻿using System;

class FN
{
    static void Main()
    {
        Console.Write("Введите четырехзначное число: ");
        int num = Convert.ToInt32(Console.ReadLine());

        int ths = num / 1000; // тысячи
        int hs = (num / 100) % 10; // сотни
        int ts = (num / 10) % 10; // десятки
        int os = num % 10; // единицы

        int prod = ths * hs * ts * os;

        Console.WriteLine("Произведение цифр числа - {0}", prod);
    }
}
