﻿using System;

class TN
{
    static void Main()
    {
        Console.Write("a = ");
        int a = Convert.ToInt32(Console.ReadLine());

        Console.Write("b = ");
        int b = Convert.ToInt32(Console.ReadLine());

        Console.Write("c =  ");
        int c = Convert.ToInt32(Console.ReadLine());

        Console.WriteLine("{0} + {1} + {2} = {2} + {1} + {0}", a, b, c);
        Console.WriteLine("Для продолжения нажмите любую клавишу . . . ");
        Console.ReadKey();
    }
}
