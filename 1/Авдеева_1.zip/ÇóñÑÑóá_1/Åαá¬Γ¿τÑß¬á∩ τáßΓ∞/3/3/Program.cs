﻿using System;

class F
{
    static void Main()
    {
        double x = 3.5;

        double numtr = Math.Pow(x, 1.5) + 1; // Числитель
        double denom = Math.Sin(x) + Math.Exp(Math.Log(2 * x)); // Знаменатель
        double frac = numtr / denom; // Деление
        double y = Math.Pow(Math.Cos(x), 2) - frac; // Итог

        Console.WriteLine("Значение функции y - {0}", Math.Round(y, 6));
    }
}
