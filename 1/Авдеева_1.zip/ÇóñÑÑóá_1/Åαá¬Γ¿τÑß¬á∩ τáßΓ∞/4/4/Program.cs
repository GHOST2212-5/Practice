﻿using System;

class T
{
    static void Main()
    {
        Console.Write("Введите высоту в метрах: ");
        double h = Convert.ToDouble(Console.ReadLine());

        double g = 9.81523;

        double t = Math.Sqrt(2 * h / g);

        Console.WriteLine("Время падения - {0} секунд(ы)", Math.Round(t, 2));
    }
}
