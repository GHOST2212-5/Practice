﻿using System;

class Z3
{
    static void Main()
    {
        double x = 0.5;

        double numtr = Math.Sin(Math.Sqrt(x)) + Math.Pow(Math.Cos(Math.Log(x)), 2); // Числитель
        double denom = Math.Sqrt(Math.Abs(1 - Math.PI * x)); // Знаменатель
        double fP = x * Math.Exp(Math.Pow(x, 2));
        double sP = numtr / denom;
        double y = fP - sP;

        Console.WriteLine("Значение y - {0}", Math.Round(y, 6));
    }
}
