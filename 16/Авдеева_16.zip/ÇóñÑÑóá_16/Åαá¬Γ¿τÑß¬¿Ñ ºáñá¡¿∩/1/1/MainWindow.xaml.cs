﻿using System.Windows;
using X.ViewModels;

namespace X
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            DataContext = new CRMViewModel();
        }
    }
}