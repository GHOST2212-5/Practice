﻿using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using X.Models;
using X.Services;

namespace X.ViewModels
{
    public class CRMViewModel : INotifyPropertyChanged
    {
        private readonly ClientService clientService;
        private bool isLoading;
        private ClientModel selectedClient;
        public ObservableCollection<ClientModel> Clients { get; private set; }
        public ObservableCollection<OrderModel> Orders { get; private set; }
        public bool IsLoading
        {
            get => isLoading;
            set { isLoading = value; OnPropertyChanged(nameof(IsLoading)); }
        }
        public ClientModel SelectedClient
        {
            get => selectedClient;
            set
            {
                selectedClient = value;
                OnPropertyChanged(nameof(SelectedClient));
                CommandManager.InvalidateRequerySuggested();
            }
        }
        public ICommand AddCommand { get; }
        public ICommand EditCommand { get; }
        public ICommand DeleteCommand { get; }
        public CRMViewModel()
        {
            clientService = new ClientService();
            Clients = new ObservableCollection<ClientModel>();
            Orders = new ObservableCollection<OrderModel>();

            AddCommand = new RelayCommand(AddClient);
            EditCommand = new RelayCommand(EditClient, CanEditOrDelete);
            DeleteCommand = new RelayCommand(DeleteClient, CanEditOrDelete);

            LoadClientsAsync();
        }
        private async void LoadClientsAsync()
        {
            IsLoading = true;
            var clients = await Task.Run(() => clientService.GetClientsAsync());
            Clients.Clear();
            foreach (var client in clients)
            {
                Clients.Add(client);
            }
            IsLoading = false;
        }
        private void AddClient(object param)
        {
            var f = new ClientFormWindow();
            if (f.ShowDialog() == true)
            {
                Clients.Add(f.Client);
            }
        }
        private void EditClient(object param)
        {
            if (SelectedClient != null)
            {
                var t = new ClientModel
                {
                    Name = SelectedClient.Name,
                    Contact = SelectedClient.Contact,
                    Email = SelectedClient.Email,
                    Type = SelectedClient.Type
                };
                var f = new ClientFormWindow(t);
                if (f.ShowDialog() == true)
                {
                    SelectedClient.Name = t.Name;
                    SelectedClient.Contact = t.Contact;
                    SelectedClient.Email = t.Email;
                    SelectedClient.Type = t.Type;
                }
            }
        }
        private void DeleteClient(object param)
        {
            if (SelectedClient != null)
            {
                MessageBoxResult r = MessageBox.Show(
                    $"Вы уверены, что хотите удалить клиента \"{SelectedClient.Name}\"?",
                    "Подтверждение удаления",
                    MessageBoxButton.YesNo,
                    MessageBoxImage.Question);

                if (r == MessageBoxResult.Yes)
                {
                    Clients.Remove(SelectedClient);
                }
            }
        }
        private bool CanEditOrDelete(object param) => SelectedClient != null;
        public event PropertyChangedEventHandler PropertyChanged;
        protected void OnPropertyChanged(string pn)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(pn));
        }
    }
}