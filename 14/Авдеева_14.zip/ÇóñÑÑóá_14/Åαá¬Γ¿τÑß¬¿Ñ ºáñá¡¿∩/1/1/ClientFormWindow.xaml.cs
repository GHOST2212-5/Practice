﻿using System.Windows;

namespace X
{
    public partial class ClientFormWindow : Window
    {
        public Client Client { get; private set; }
        public ClientFormWindow(Client client = null)
        {
            InitializeComponent();
            Client = client ?? new Client();
            NameTextBox.Text = Client.Name;
            ContactTextBox.Text = Client.Contact;
            HistoryTextBox.Text = Client.History;
        }
        private void SaveButton_Click(object sender, RoutedEventArgs e)
        {
            Client.Name = NameTextBox.Text;
            Client.Contact = ContactTextBox.Text;
            Client.History = HistoryTextBox.Text;
            DialogResult = true;
            Close();
        }
        private void CancelButton_Click(object sender, RoutedEventArgs e)
        {
            DialogResult = false;
            Close();
        }
    }
}