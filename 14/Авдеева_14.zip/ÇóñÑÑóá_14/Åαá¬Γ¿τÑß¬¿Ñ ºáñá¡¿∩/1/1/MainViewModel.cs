﻿using System.Collections.ObjectModel;
using System.Windows;
using System.Windows.Input;

namespace X
{
    public class MainViewModel
    {
        public ObservableCollection<Client> Clients { get; set; }
        public Client SelectedClient { get; set; }
        public ICommand AddClientCommand { get; }
        public ICommand EditClientCommand { get; }
        public ICommand DeleteClientCommand { get; }
        public MainViewModel()
        {
            Clients = new ObservableCollection<Client>
            {
                new Client { Name = "Ангелина Авдеева", Contact = "+37529. . . . . . .", History = "Первичный контакт" },
                new Client { Name = "Имя Фамилия", Contact = "+3752912345679", History = "Информация" }
            };
            AddClientCommand = new RelayCommand(AddClient);
            EditClientCommand = new RelayCommand(EditClient, CanEditOrDelete);
            DeleteClientCommand = new RelayCommand(DeleteClient, CanEditOrDelete);
        }
        private void AddClient(object param)
        {
            var f = new ClientFormWindow();
            if (f.ShowDialog() == true)
            {
                Clients.Add(f.Client);
            }
        }
        private void EditClient(object param)
        {
            if (SelectedClient != null)
            {
                var f = new ClientFormWindow(SelectedClient);
                if (f.ShowDialog() == true)
                {
                }
            }
        }
        private void DeleteClient(object param)
        {
            if (SelectedClient != null)
            {
                if (MessageBox.Show($"Удалить клиента {SelectedClient.Name}?", "Подтверждение", MessageBoxButton.YesNo) == MessageBoxResult.Yes)
                {
                    Clients.Remove(SelectedClient);
                }
            }
        }
        private bool CanEditOrDelete(object param)
        {
            return SelectedClient != null;
        }
    }
}