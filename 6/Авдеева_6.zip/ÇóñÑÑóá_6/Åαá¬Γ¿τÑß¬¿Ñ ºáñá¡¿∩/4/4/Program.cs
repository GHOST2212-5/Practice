﻿using System;

namespace N
{
    public interface IEmailNotifier
    {
        void SendNotification(string m);
    }

    public interface ISmsNotifier
    {
        void SendNotification(string m);
    }

    public class NotificationService : IEmailNotifier, ISmsNotifier
    {
        void IEmailNotifier.SendNotification(string m)
        {
            Console.WriteLine($"Уведомление от email: {m}");
        }

        void ISmsNotifier.SendNotification(string m)
        {
            Console.WriteLine($"Sms-уведомление: {m}");
        }
    }

    class NS
    {
        static void Main()
        {
            NotificationService s = new NotificationService();

            IEmailNotifier ien = s;
            ien.SendNotification("Откройте, чтобы прочитать новое письмо...");

            ISmsNotifier isn = s;
            isn.SendNotification("Кот, собака и корова это животные :о ");
        }
    }
}
