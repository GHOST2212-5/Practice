﻿using System;
using System.Xml.Linq;

namespace V
{
    public class Vehicle
    {
        public string N { get; set; }

        public Vehicle(string n)
        {
            N = n;
        }

        public virtual void I()
        {
            Console.WriteLine($"Транспортное средство: {N}");
        }
    }

    public interface IElectric
    {
        void B();
    }

    public interface IDiesel
    {
        void R();
    }

    public class ElectricCar : Vehicle, IElectric
    {
        public ElectricCar(string n) : base(n) { }

        public void B()
        {
            Console.WriteLine($"{N} заряжается.");
        }

        public override void I()
        {
            base.I();
            Console.WriteLine("Тип: Электромобиль");
        }
    }

    public class Truck : Vehicle, IDiesel
    {
        public Truck(string n) : base(n) { }

        public void R()
        {
            Console.WriteLine($"{N}");
        }

        public override void I()
        {
            base.I();
            Console.WriteLine("Тип: Дизельная машина");
        }
    }

    class C
    {
        static void Main()
        {
            Vehicle[] vs = {
                new ElectricCar("Audi e-tron"),
                new Truck("Scania R500"),
                new ElectricCar("BMW i3"),
                new Truck("Mercedes-Benz Actros")
            };

            Console.WriteLine("  Все транспортные средства");
            foreach (var v in vs)
            {
                v.I();
                Console.WriteLine();
            }

            Console.WriteLine("Дизельные машины:");
            foreach (var v in vs)
            {
                if (v is IDiesel d)
                {
                    d.R();
                }
            }
        }
    }
}
