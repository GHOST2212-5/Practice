﻿using System;

namespace E
{
    public class Author
    {
        public string N { get; set; }

        public Author(string n)
        {
            N = n;
        }
    }

    public class TableOfContents
    {
        public string[] Cs { get; set; }

        public TableOfContents(string[] cs)
        {
            Cs = cs;
        }

        public void DisplayContents()
        {
            Console.WriteLine("Содержание:");
            foreach (var c in Cs)
            {
                Console.WriteLine($"- {c}");
            }
        }
    }

    public class Book
    {
        public string T { get; set; }
        public Author[] A { get; set; } // агрегация
        public TableOfContents Cs { get; set; } // композиция

        public Book(string t, Author[] a, string[] cs)
        {
            T = t;
            A = a;
            Cs = new TableOfContents(cs);
        }

        public void DisplayInfo()
        {
            Console.WriteLine($"-- {T}");
            Console.WriteLine("Авторы:");
            foreach (var a in A)
            {
                Console.WriteLine($"- {a.N}");
            }
            Cs.DisplayContents();
        }
    }

    public class Library
    {
        public string N { get; set; }
        public Book[] Bs { get; set; }

        public Library(string n, Book[] bs)
        {
            N = n;
            Bs = bs;
        }

        public void DisplayLibraryInfo()
        {
            Console.WriteLine($"Библиотека: {N}");
            Console.WriteLine("Книги:");
            foreach (var book in Bs)
            {
                book.DisplayInfo();
                Console.WriteLine();
            }
        }
    }

    class AB
    {
        static void Main()
        {
            var a1 = new Author("Джоан Роулинг");
            var a2 = new Author("Оскар Уайльд");

            var b1 = new Book(
                "Гарри Поттер и философский камень",
                new[] { a1 },
                new[] { "Глава 1: Мальчик, который выжил", "Глава 2: Письма из Хогвартса" }
            );

            var b2 = new Book(
                "Портрет Дориана Грея",
                new[] { a2 },
                new[] { "Глава 1: Художник и его модель", "Глава 2: Загадочное зеркало" }
            );

            var library = new Library("Моя", new[] { b1, b2 });

            library.DisplayLibraryInfo();
        }
    }
}
