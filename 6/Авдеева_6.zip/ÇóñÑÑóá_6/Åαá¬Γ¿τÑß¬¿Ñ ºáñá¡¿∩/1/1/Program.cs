﻿using System;

namespace Ams
{
    public abstract class Animal
    {
        public abstract string Name { get; }
        public abstract void MakeSound();
    }
    public class Dog : Animal
    {
        public override string Name => "Собака";
        public override void MakeSound()
        {
            Console.WriteLine($"{Name}: Woof!");
        }
    }
    public class Cat : Animal
    {
        public override string Name => "Кот";
        public override void MakeSound()
        {
            Console.WriteLine($"{Name}: Meow!");
        }
    }
    public class Cow : Animal
    {
        public override string Name => "Корова";
        public override void MakeSound()
        {
            Console.WriteLine($"{Name}: Moo!");
        }
    }

    class A
    {
        static void Main()
        {
            Animal[] ams = { new Dog(), new Cat(), new Cow() };

            Console.WriteLine("Звуки, издаваемые животными:");
            foreach (Animal am in ams)
            {
                am.MakeSound();
            }
        }
    }
}
