﻿using System;
using System.IO;
using System.Threading;

namespace E
{
    public class FileWatcher
    {
        private string _w;
        private string _b;
        public FileWatcher(string w, string b)
        {
            _w = w;
            _b = b;

            if (!Directory.Exists(_b))
            {
                Directory.CreateDirectory(_b);
                Console.WriteLine($"Папка резервного копирования создана: {_b}");
            }
        }
        public void StartWatching()
        {
            using (FileSystemWatcher wr = new FileSystemWatcher())
            {
                wr.Path = _w;
                wr.NotifyFilter = NotifyFilters.LastWrite | NotifyFilters.FileName;
                wr.IncludeSubdirectories = false;
                wr.Created += OnCreated;
                wr.Changed += OnChanged;
                wr.Deleted += OnDeleted;
                wr.Renamed += OnRenamed;
                wr.EnableRaisingEvents = true;
                Console.WriteLine("Нажмите любую клавишу для выхода...");
                Console.ReadKey();
            }
        }
        private void OnCreated(object s, FileSystemEventArgs e)
        {
            if (IsTemporaryFile(e.Name)) return;

            Console.WriteLine($"Создан файл: {e.Name}");
            TryBackup(e.FullPath);
        }
        private void OnChanged(object s, FileSystemEventArgs e)
        {
            if (IsTemporaryFile(e.Name)) return;

            Console.WriteLine($"Файл изменён: {e.Name}");
            TryBackup(e.FullPath);
        }
        private void OnDeleted(object s, FileSystemEventArgs e)
        {
            if (IsTemporaryFile(e.Name)) return;

            Console.WriteLine($"Файл удален: {e.Name}");
        }
        private void OnRenamed(object s, RenamedEventArgs e)
        {
            if (IsTemporaryFile(e.Name) || IsTemporaryFile(e.OldName)) return;

            Console.WriteLine($"Файл переименован с {e.OldName} на {e.Name}");
            TryBackup(e.FullPath);
        }
        private void TryBackup(string f)
        {
            try
            {
                for (int a = 0; a < 5; a++)
                {
                    if (File.Exists(f))
                    {
                        BackupFile(f);
                        return;
                    }
                    Thread.Sleep(500);
                }

                Console.WriteLine($"Не удалось создать резервную копию - файл недоступен {f}");
            }
            catch (Exception x)
            {
                Console.WriteLine($"{f}: {x.Message}");
            }
        }
        private void BackupFile(string f)
        {
            try
            {
                string N = Path.GetFileNameWithoutExtension(f);
                string S = DateTime.Now.ToString("yyyyMMdd_HHmmss");
                string fn = $"{N}_{S}.bak";
                string bp = Path.Combine(_b, fn);

                File.Copy(f, bp, true);
                Console.WriteLine($"Создана резервная копия: {bp}");
            }
            catch (Exception x)
            {
                Console.WriteLine($"{x.Message}");
            }
        }
        private bool IsTemporaryFile(string N)
        {
            return N.StartsWith("~$") || N.EndsWith(".tmp") || N.StartsWith("~WR");
        }
    }

    class CDCR
    {
        static void Main()
        {
            string D = @"E:\COLLEGE\Practice";
            string B = @"C:\backup";

            FileWatcher wr = new FileWatcher(D, B);
            wr.StartWatching();
        }
    }
}