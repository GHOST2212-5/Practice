﻿using System;
using System.Collections.Generic;
using System.IO;

namespace E
{
    public class Product
    {
        public string Name { get; set; }
        public decimal Price { get; set; }
        public string Category { get; set; }
        public Product(string n, decimal p, string c)
        {
            Name = n;
            Price = p;
            Category = c;
        }
    }
    public class ProductFileWriter
    {
        private string _f;
        public ProductFileWriter(string f)
        {
            _f = f;
        }
        public void WriteProducts(List<Product> products)
        {
            using (BinaryWriter w = new BinaryWriter(File.Open(_f, FileMode.Create)))
            {
                foreach (var product in products)
                {
                    w.Write(product.Name);
                    w.Write(product.Price);
                    w.Write(product.Category);
                }
            }
            Console.WriteLine($"Товары в {_f}.");
        }
    }
    public class ProductFileReader
    {
        private string _f;
        public ProductFileReader(string f)
        {
            _f = f;
        }
        public void ReadProducts()
        {
            using (BinaryReader r = new BinaryReader(File.Open(_f, FileMode.Open)))
            {
                Console.WriteLine("Продукты:");
                while (r.BaseStream.Position < r.BaseStream.Length)
                {
                    string n = r.ReadString();
                    decimal p = r.ReadDecimal();
                    string c = r.ReadString();

                    Console.WriteLine($"Название: {n}; Цена: {p}; Категория: {c}.");
                }
            }
        }
    }

    class M
    {
        static void Main()
        {
            List<Product> products = new List<Product>
            {
                new Product("Молоко", 2.2m, "Напитки"),
                new Product("Шоколад", 5.75m, "Сладкое"),
                new Product("Кукуруза", 1.3m, "Овощи")
            };
            string f = "file.data";
            ProductFileWriter w = new ProductFileWriter(f);
            w.WriteProducts(products);
            ProductFileReader r = new ProductFileReader(f);
            r.ReadProducts();
            Console.WriteLine("Запись завершена.");
        }
    }
}
