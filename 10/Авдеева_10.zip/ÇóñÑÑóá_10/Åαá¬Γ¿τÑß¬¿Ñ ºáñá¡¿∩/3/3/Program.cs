﻿using System;
using System.Collections.Generic;
using System.IO;

namespace E
{
    public class Product
    {
        public string Name { get; set; }
        public decimal Price { get; set; }
        public string Category { get; set; }

        public Product(string n, decimal p, string c)
        {
            Name = n;
            Price = p;
            Category = c;
        }
    }
    public class ProductFileReader
    {
        private string _f;

        public ProductFileReader(string f)
        {
            _f = f;
        }

        public List<Product> ReadProducts()
        {
            var products = new List<Product>();
            if (!File.Exists(_f))
            {
                Console.WriteLine($"Файл '{_f}' не найден.");
                return products;
            }
            using (BinaryReader r = new BinaryReader(File.Open(_f, FileMode.Open)))
            {
                if (r.BaseStream.Length == 0)
                {
                    Console.WriteLine($"Файл '{_f}' пуст.");
                    return products;
                }
                while (r.BaseStream.Position < r.BaseStream.Length)
                {
                    string n = r.ReadString();
                    decimal p = r.ReadDecimal();
                    string c = r.ReadString();

                    products.Add(new Product(n, p, c));
                }
            }
            Console.WriteLine("Товары выгружены из файла.");
            return products;
        }
    }
    public class ProductProcessor
    {
        public List<Product> SortByPrice(List<Product> products, bool ascending)
        {
            if (ascending)
            {
                products.Sort((p1, p2) => p1.Price.CompareTo(p2.Price));
            }
            else
            {
                products.Sort((p1, p2) => p2.Price.CompareTo(p1.Price));
            }

            Console.WriteLine("Сортировка товаров по цене завершена:");
            return products;
        }
    }

    class M2
    {
        static void Main()
        {
            string f = @"E:\COLLEGE\Practice\10\Авдеева_10\Практические задания\2\2\bin\Debug\net8.0\file.data"; //Путь придется изменить
            ProductFileReader r = new ProductFileReader(f);
            List<Product> products = r.ReadProducts();
            if (products.Count == 0)
            {
                Console.WriteLine("Нет данных для сортировки.");
                return;
            }
            ProductProcessor pr = new ProductProcessor();

            Console.WriteLine("\nСортировка по возрастанию.");
            List<Product> sa = pr.SortByPrice(products, true);
            foreach (var product in sa)
            {
                Console.WriteLine($"Название: {product.Name}; Цена: {product.Price}; Категория: {product.Category}");
            }

            Console.WriteLine("\nСортировка по убыванию.");
            List<Product> sd = pr.SortByPrice(products, false);
            foreach (var product in sd)
            {
                Console.WriteLine($"Название: {product.Name}; Цена: {product.Price}; Категория: {product.Category}");
            }
        }
    }
}
