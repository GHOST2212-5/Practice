﻿using System;
using System.IO;

namespace E
{
    public class FileManager
    {
        public void CreateFile(string p, string c)
        {
            File.WriteAllText(p, c);
            Console.WriteLine($"Создан файл: {p}");
        }
        public void CopyFile(string s, string d)
        {
            if (File.Exists(s))
            {
                File.Copy(s, d, true);
                Console.WriteLine($"Скопировано в файл {d}");
            }
            else
            {
                Console.WriteLine("Исходный файл не найден.");
            }
        }
        public void DeleteFile(string p)
        {
            if (File.Exists(p))
            {
                File.Delete(p);
                Console.WriteLine($"Файл {p} удалён.");
            }
            else
            {
                Console.WriteLine("Файл не существует.");
            }
        }
        public void MoveFile(string s, string d)
        {
            if (File.Exists(s))
            {
                if (File.Exists(d))
                {
                    File.Delete(d);
                }
                File.Move(s, d);
                Console.WriteLine($"Перемещено в файл {d}");
            }
            else
            {
                Console.WriteLine("Файл не найден.");
            }
        }
        public void RenameFile(string s, string n)
        {
            if (File.Exists(s))
            {
                string np = Path.Combine(Path.GetDirectoryName(s), n);
                if (File.Exists(np))
                {
                    File.Delete(np);
                }
                File.Move(s, np);
                Console.WriteLine($"Файл переименован в {np}");
            }
            else
            {
                Console.WriteLine("Файл не найден.");
            }
        }
    }
    public class FileInfoProvider
    {
        public void GetFileInfo(string p)
        {
            if (File.Exists(p))
            {
                FileInfo I = new FileInfo(p);
                Console.WriteLine($"Размер: {I.Length} байт");
                Console.WriteLine($"Дата создания: {I.CreationTime}");
                Console.WriteLine($"Дата последнего изменения: {I.LastWriteTime}");
            }
            else
            {
                Console.WriteLine("Файл не найден.");
            }
        }
        public void CompareFileSizes(string p1, string p2)
        {
            if (File.Exists(p1) && File.Exists(p2))
            {
                FileInfo f1 = new FileInfo(p1);
                FileInfo f2 = new FileInfo(p2);
                if (f1.Length > f2.Length)
                {
                    Console.WriteLine("Первый файл больше второго.");
                }
                else if (f1.Length < f2.Length)
                {
                    Console.WriteLine("Второй файл больше первого.");
                }
                else
                {
                    Console.WriteLine("Файлы одинакового размера.");
                }
            }
            else
            {
                Console.WriteLine("Не найдено.");
            }
        }
    }

    class AAV
    {
        static void Main()
        {
            FileManager m = new FileManager();
            FileInfoProvider ip = new FileInfoProvider();

            string fp = "t.txt";
            string cp = "copy_t.txt";
            string D = "N";
            string r = "Avdeeva.AV";

            // 1
            m.CreateFile(fp, "Авдеева Ангелина Владимировна");
            Console.WriteLine(File.ReadAllText(fp));
            // 2
            m.DeleteFile(fp);
            // 3
            m.CreateFile(fp, "Файл.");
            ip.GetFileInfo(fp);
            // 4
            m.CopyFile(fp, cp);
            // 5
            Directory.CreateDirectory(D);
            m.MoveFile(cp, Path.Combine(D, "m_t.txt"));
            // 6
            m.RenameFile(fp, r);
            // 7
            m.DeleteFile("ne.txt");
            // 8
            m.CreateFile("f1.txt", "Пример");
            m.CreateFile("f2.txt", "Пример длиннее");
            ip.CompareFileSizes("f1.txt", "f2.txt");
            // 9
            string[] fd = Directory.GetFiles(D, "*.txt");
            foreach (var f in fd)
            {
                m.DeleteFile(f);
            }
            // 10
            string[] fs = Directory.GetFiles(Directory.GetCurrentDirectory());
            foreach (var f in fs)
            {
                Console.WriteLine(f);
            }
            // 11
            if (File.Exists(fp))
            {
                File.SetAttributes(fp, FileAttributes.ReadOnly);
                try
                {
                    m.CreateFile(fp, "Проверка");
                }
                catch (UnauthorizedAccessException)
                {
                    Console.WriteLine("Запись в файл запрещена.");
                }
            }
            else
            {
                Console.WriteLine($"Файл '{fp}' не найден, нельзя изменить атрибуты.");
            }
            // 12
            if (File.Exists(fp))
            {
                Console.WriteLine($"Доступен для чтения: {File.GetAttributes(fp).HasFlag(FileAttributes.ReadOnly)}");
            }
            else
            {
                Console.WriteLine($"Файл '{fp}' не найден, нельзя проверить доступ.");
            }
        }
    }
}
