﻿using System;

class TDA
{
    static void Main()
    {
        Console.Write("Введите кол-во строк массива: ");
        int rs = Convert.ToInt32(Console.ReadLine());
        Console.Write("Введите кол-во столбцов..: ");
        int cs = Convert.ToInt32(Console.ReadLine());

        int[,] mx = new int[rs, cs];
        Random random = new Random();

        Console.WriteLine("\nДвумерный массив:");
        for (int i = 0; i < rs; i++)
        {
            for (int j = 0; j < cs; j++)
            {
                mx[i, j] = random.Next(-15, 16);
                Console.Write(mx[i, j] + "\t");
            }
            Console.WriteLine();
        }

        Console.Write("\nВведите строку для проверки (1<N): ");
        int RC = Convert.ToInt32(Console.ReadLine()) - 1;

        Console.Write("Введите заданное число: ");
        int num = Convert.ToInt32(Console.ReadLine());

        int sum = 0;
        for (int j = 0; j < cs; j++)
        {
            sum += mx[RC, j];
        }
        Console.WriteLine($"\nСумма эл-ов строки {RC + 1}: {sum}");

        if (sum > num)
        {
            Console.WriteLine($"Сумма строки для проверки под номером {RC + 1} превышает заданное число равное {num}.");
        }
        else
        {
            Console.WriteLine($"Сумма строки для проверки под номером {RC + 1} не превышает заданное число равное {num}.");
        }
    }
}
