﻿using System;
using System.Collections.Generic;

class Fon
{
    static void Main()
    {
        Console.WriteLine("Введите строку.");
        string ip = Console.ReadLine();

        string[] ws = ip.Split(new char[] { ' ', '.', ',', '!', '?' }, StringSplitOptions.RemoveEmptyEntries);

        Dictionary<string, int> wc = new Dictionary<string, int>();

        foreach (string w in ws)
        {
            string l = w.ToLower();
            if (wc.ContainsKey(l))
            {
                wc[l]++;
            }
            else
            {
                wc[l] = 1;
            }
        }

        string fw = null;
        int mc = 0;

        foreach (var p in wc)
        {
            if (p.Value > mc)
            {
                mc = p.Value;
                fw = p.Key;
            }
        }

        if (fw != null)
        {
            Console.WriteLine($"Самое часто встречающееся слово - \"{fw}\"");
            Console.WriteLine($"Частота: {mc}");
        }
        else
        {
            Console.WriteLine("В строке нет слов.");
        }
    }
}
