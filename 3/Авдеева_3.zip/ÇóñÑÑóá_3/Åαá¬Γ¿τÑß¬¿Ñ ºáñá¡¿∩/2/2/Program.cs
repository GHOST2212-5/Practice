﻿using System;

class NO
{
    static void Main()
    {
        int[] nums = new int[50];
        Random random = new Random();

        for (int i = 0; i < nums.Length; i++)
        {
            nums[i] = random.Next(1, 101);
        }

        Console.WriteLine("Исходный массив:");
        for (int i = 0; i < nums.Length; i++)
        {
            Console.Write(nums[i] + " ");
        }
        Console.WriteLine();

        int l = nums[nums.Length - 1];
        Console.WriteLine("Последнее число: " + l);

        int D = 0;
        for (int i = 0; i < nums.Length; i++)
        {
            if (nums[i] != l)
            {
                D++;
            }
        }
        Console.WriteLine("Кол-во чисел, отличных от последнего: " + D);

        Array.Sort(nums);

        Console.WriteLine("Отсортированный массив:");
        for (int i = 0; i < nums.Length; i++)
        {
            Console.Write(nums[i] + " ");
        }
        Console.WriteLine();

        Console.Write("Введите k для бинарного поиска: ");
        int k = Convert.ToInt32(Console.ReadLine());
        int ind = Array.BinarySearch(nums, k);

        if (ind >= 0)
        {
            Console.WriteLine(k + " найдено на позиции: " + ind);
        }
        else
        {
            Console.WriteLine(k + " не найдено.");
        }
    }
}
