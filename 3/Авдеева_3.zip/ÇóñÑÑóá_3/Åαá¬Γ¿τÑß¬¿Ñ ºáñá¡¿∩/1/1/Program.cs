﻿using System;

class AQ
{
    static void Main()
    {
        double[] nums = { 1.2, 3.4, 5.6, 7.8, 9.0 };

        double sum = 0;
        int c = 0;

        for (int i = 0; i < nums.Length; i++)
        {
            sum += nums[i];
            c++;
        }

        Console.WriteLine("Сумма эл-в массива: " + sum);
        Console.WriteLine("Кол-во эл-в массива: " + c);
    }
}