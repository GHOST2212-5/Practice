﻿using System;
using System.Text.RegularExpressions;

class EA
{
    static void Main()
    {
        Console.Write("Введите email-адрес: ");
        string e = Console.ReadLine();
        string p = @"^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9-.]+$";
        bool v = Regex.IsMatch(e, p);

        if (v)
        {
            Console.WriteLine("Корректен.");
        }
        else
        {
            Console.WriteLine("Некорректен.");
        }
    }
}
