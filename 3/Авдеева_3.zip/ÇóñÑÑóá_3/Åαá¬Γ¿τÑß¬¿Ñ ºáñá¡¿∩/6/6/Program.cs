﻿using System;

class Clod
{
    static void Main()
    {
        Console.Write("Введите строку: ");
        string ip = Console.ReadLine();

        bool c= false;

        for (int i = 0; i < ip.Length; i++)
        {
            if (char.IsDigit(ip[i]))
            {
                c = true;
                break;
            }
        }

        if (c)
        {
            Console.WriteLine("Строка содержит хотя бы одну цифру.");
        }
        else
        {
            Console.WriteLine("В строке нет цифр.");
        }
    }
}
