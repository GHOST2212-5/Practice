﻿using System;
using System.Text;

class SB
{
    static void Main()
    {
        StringBuilder sb = new StringBuilder("Я Авдеева Ангелина, ");
        sb.Append("41ТП.");

        Console.WriteLine(sb.ToString());
    }
}
