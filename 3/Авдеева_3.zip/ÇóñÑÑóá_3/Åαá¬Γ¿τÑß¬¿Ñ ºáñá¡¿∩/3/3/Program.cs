﻿using System;

class KS
{
    static void Main()
    {
        Console.Write("Введите размер матрицы (N < 10): ");
        int N = Convert.ToInt32(Console.ReadLine());

        Console.Write("Введите начало диапазона: ");
        int a = Convert.ToInt32(Console.ReadLine());
        Console.Write("Введите конец диапазона: ");
        int b = Convert.ToInt32(Console.ReadLine());

        int[,] mx = new int[N, N];
        Random random = new Random();

        Console.WriteLine("\nИсходная матрица:");
        for (int i = 0; i < N; i++)
        {
            for (int j = 0; j < N; j++)
            {
                mx[i, j] = random.Next(a, b + 1);
                Console.Write(mx[i, j] + "\t");
            }
            Console.WriteLine();
        }

        int SN = 0;
        for (int i = 0; i < N; i++)
        {
            for (int j = 0; j < N; j++)
            {
                if (mx[i, j] < 0)
                {
                    SN += mx[i, j];
                }
            }
        }
        Console.WriteLine("\nСумма отриц-х эл-ов: " + SN);

        Console.WriteLine("\nКол-во чётных эл-ов в каждой строке:");
        for (int i = 0; i < N; i++)
        {
            int EC = 0;
            for (int j = 0; j < N; j++)
            {
                if (mx[i, j] % 2 == 0)
                {
                    EC++;
                }
            }
            Console.WriteLine($"Строка - {i + 1}, {EC} чётных элементов");
        }
    }
}
