﻿using System;

class RS
{
    static void Main()
    {
        Console.WriteLine("Введите строку.");
        string ip = Console.ReadLine();
        string r = ip.Replace(" ", "");

        Console.WriteLine("Строка без пробелов: " + r);
    }
}
