﻿using System;

class Lse
{
    static void Main()
    {
        Console.Write("Введите кол-во строк массива: ");
        int rs = Convert.ToInt32(Console.ReadLine());

        int[][] A = new int[rs][];
        Random random = new Random();

        for (int i = 0; i < rs; i++)
        {
            Console.Write($"Введите кол-во эл-ов в строке {i + 1}: ");
            int cs = Convert.ToInt32(Console.ReadLine());
            A[i] = new int[cs];

            for (int j = 0; j < cs; j++)
            {
                A[i][j] = random.Next(-10, 11);
            }
        }

        Console.WriteLine("\nСтупенчатый массив:");
        for (int i = 0; i < rs; i++)
        {
            for (int j = 0; j < A[i].Length; j++)
            {
                Console.Write(A[i][j] + " ");
            }
            Console.WriteLine();
        }

        int mxs = int.MinValue;
        int mxi = -1;

        for (int i = 0; i < rs; i++)
        {
            int cs = 0;
            for (int j = 0; j < A[i].Length; j++)
            {
                cs += A[i][j];
            }

            if (cs > mxs)
            {
                mxs = cs;
                mxi = i;
            }
        }

        Console.WriteLine($"\nС наибольшей суммой элементов: {mxi + 1} строка");
        Console.WriteLine($"Сумма элементов этой строки равна {mxs}.");
    }
}
