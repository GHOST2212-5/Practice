﻿using System;

namespace E
{
    public delegate void SC(string n);
    public class OrderStatusManager
    {
        public event SC StatusChanged;

        public void UpdateStatus(string n)
        {
            Console.WriteLine($"Статус заказа изменён на: {n}");
            StatusChanged?.Invoke(n);
        }
    }
    public class CustomerNotifier
    {
        public void C(string m)
        {
            Console.Write($"Оповещение клиенту: {m}; ");
        }
    }
    public class AdminLogger
    {
        public void S(string m)
        {
            Console.WriteLine($"Запись в лог: {m}.");
        }
    }

    class T
    {
        static void Main()
        {
            OrderStatusManager o = new OrderStatusManager();
            CustomerNotifier c = new CustomerNotifier();
            AdminLogger a = new AdminLogger();

            o.StatusChanged += c.C;
            o.StatusChanged += a.S;
            o.UpdateStatus("Произошла ошибка при оплате");
            o.UpdateStatus("Заказ ожидает оплаты");
            o.UpdateStatus("Заказ оплачен");
        }
    }
}
