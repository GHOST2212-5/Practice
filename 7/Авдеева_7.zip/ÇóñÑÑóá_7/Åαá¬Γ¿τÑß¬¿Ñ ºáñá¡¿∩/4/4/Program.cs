﻿using System;

namespace E
{
    public class TemperatureSensor
    {
        public event EventHandler<double> TemperatureChanged;
        public void S(double n)
        {
            Console.WriteLine($"Температура изменилась, новое значение: {n}°C");
            TemperatureChanged?.Invoke(this, n);
        }
    }
    public class TemperatureMonitor
    {
        private readonly TemperatureSensor _s;
        public TemperatureMonitor(TemperatureSensor s)
        {
            _s = s;
        }
        public void C(CoolingSystem cs, AlarmSystem a)
        {
            _s.TemperatureChanged += a.at;
            _s.TemperatureChanged += cs.ac;
        }
    }
    public class CoolingSystem
    {
        public void ac(object sr, double t)
        {
            if (t > 25)
            {
                Console.WriteLine("Система охлаждения: включён кондиционер.");
            }
        }
    }
    public class AlarmSystem
    {
        public void at(object sr, double t)
        {
            if (t > 30)
            {
                Console.WriteLine("Система оповещения: перегрев!");
            }
        }
    }

    class TCA
    {
        static void Main()
        {
            TemperatureSensor s = new TemperatureSensor();
            CoolingSystem cs = new CoolingSystem();
            AlarmSystem a = new AlarmSystem();
            TemperatureMonitor m = new TemperatureMonitor(s);

            m.C(cs, a);
            s.S(23);
            s.S(26);
            s.S(35);
        }
    }
}
