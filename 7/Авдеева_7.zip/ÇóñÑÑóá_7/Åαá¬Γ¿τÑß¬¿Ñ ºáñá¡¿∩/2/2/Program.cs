﻿using System;

namespace E
{
    public delegate double MathOperation(double a, double b);
    public class T
    {
        public double Calculate(double a, double b, MathOperation o)
        {
            return o(a, b);
        }
        public double Add(double a, double b)
        {
            return a + b;
        }
        public double Multiply(double a, double b)
        {
            return a * b;
        }
    }

    class MO
    {
        static void Main()
        {
            T t = new T();
            MathOperation o = t.Add;
            double s = t.Calculate(1, 2, o);
            Console.WriteLine($"1 + 2 = {s}");
            o = t.Multiply;
            double p = t.Calculate(3, 4, o);
            Console.WriteLine($"3 * 4 = {p}");
        }
    }
}
