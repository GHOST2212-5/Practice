﻿using System;

namespace E
{
    public delegate double MathOperation(double a, double b);
    public class Addition
    {
        public double Add(double a, double b)
        {
            return a + b;
        }
    }
    public class Multiplication
    {
        public double Multiply(double a, double b)
        {
            return a * b;
        }
    }

    class MD
    {
        static void Main()
        {
            Addition ad = new Addition();
            Multiplication m = new Multiplication();

            MathOperation o = ad.Add;
            Console.WriteLine($"1 + 2 = {o(1, 2)}");
            o = m.Multiply;
            Console.WriteLine($"3 * 4 = {o(3, 4)}");
        }
    }
}
