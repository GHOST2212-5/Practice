﻿using System;
using System.IO;
using System.Text.Json;

namespace E
{
    public class ParsingException : Exception
    {
        public ParsingException(string m) : base(m) { }

        public ParsingException(string m, Exception innerException) : base(m, innerException) { }
    }
    public class JsonParser
    {
        public void Parse(string json)
        {
            if (string.IsNullOrWhiteSpace(json) || !json.StartsWith("{") || !json.EndsWith("}"))
            {
                throw new JsonException("Некорректная строка.");
            }

            Console.WriteLine("Парсинг успешно завершен.");
        }
    }
    public class DataProcessor
    {
        private readonly JsonParser _p = new JsonParser();

        public void D(string json)
        {
            try
            {
                _p.Parse(json);
            }
            catch (JsonException e)
            {
                throw new ParsingException("Ошибка при парсинге.", e);
            }
        }
    }

    class EWPJ
    {
        static void Main()
        {
            DataProcessor p = new DataProcessor();
            try
            {
                Console.Write("Введите строку JSON: ");
                string ji = Console.ReadLine();

                p.D(ji);
            }
            catch (ParsingException e)
            {
                Console.WriteLine($"{e.Message}");
                Console.WriteLine($"Внутреннее исключение: {e.InnerException?.Message}");
                File.WriteAllText("log.txt", $"{e.Message}\nСтек вызовов:\n{e.StackTrace}");
                Console.WriteLine("Детали ошибки записаны в log.txt.");
            }
        }
    }
}
