﻿using System;

namespace E
{
    public class InvalidAccountNumberException : Exception
    {
        public InvalidAccountNumberException()
            : base("Некорректный номер банковского счета.") { }

        public InvalidAccountNumberException(string m)
            : base(m) { }

        public InvalidAccountNumberException(string m, Exception innerException)
            : base(m, innerException) { }
    }
    public class BankAccount
    {
        public void ValidateAccount(string accountNumber)
        {
            if (accountNumber.Length != 10 || !long.TryParse(accountNumber, out _))
            {
                throw new InvalidAccountNumberException($"Номер счета должен содержать ровно 10 цифр. Вы ввели \"{accountNumber}\".");
            }
        }
    }

    class BAV
    {
        static void Main()
        {
            BankAccount a = new BankAccount();

            try
            {
                Console.Write("Введите номер банковского счета: ");
                string accountNumber = Console.ReadLine();

                a.ValidateAccount(accountNumber);
                Console.WriteLine("Номер счета корректен!");
            }
            catch (InvalidAccountNumberException e)
            {
                Console.WriteLine($"{e.Message}");
            }
        }
    }
}
