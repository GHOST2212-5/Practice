﻿using System;

namespace E
{
    public class InsufficientFundsException : Exception
    {
        public InsufficientFundsException()
            : base("Недостаточно средств.") { }
        public InsufficientFundsException(string m)
            : base(m) { }
        public InsufficientFundsException(string m, Exception innerException)
            : base(m, innerException) { }
    }
    public class BankAccount
    {
        public decimal B { get; private set; }
        public BankAccount(decimal i)
        {
            B = i;
        }
        public void Withdraw(decimal amount)
        {
            if (amount > B)
            {
                throw new InsufficientFundsException(
                    $"{amount} превышает текущий баланс {B}.");
            }
            B -= amount;
            Console.WriteLine($"Успешно выполнено. Остаток на счете: {B}.");
        }
    }

    class CBBWF
    {
        static void Main()
        {
            BankAccount a = new BankAccount(100.0m);
            try
            {
                Console.Write("Введите сумму для снятия: ");
                decimal amount = Convert.ToDecimal(Console.ReadLine());
                a.Withdraw(amount);
            }
            catch (InsufficientFundsException e)
            {
                Console.WriteLine($"{e.Message}");
            }
        }
    }
}
