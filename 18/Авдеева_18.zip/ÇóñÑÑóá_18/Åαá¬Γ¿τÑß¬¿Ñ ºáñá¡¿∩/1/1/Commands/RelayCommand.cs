﻿using System;
using System.Windows.Input;

namespace X
{
    public class RelayCommand : ICommand
    {
        private readonly Action<object> ec;
        private readonly Predicate<object> ce;
        public RelayCommand(Action<object> ec, Predicate<object> ce = null)
        {
            this.ec = ec ?? throw new ArgumentNullException(nameof(ec));
            this.ce = ce;
        }
        public bool CanExecute(object param) => ce?.Invoke(param) ?? true;
        public void Execute(object param) => ec(param);
        public event EventHandler CanExecuteChanged
        {
            add => CommandManager.RequerySuggested += value;
            remove => CommandManager.RequerySuggested -= value;
        }
    }
}