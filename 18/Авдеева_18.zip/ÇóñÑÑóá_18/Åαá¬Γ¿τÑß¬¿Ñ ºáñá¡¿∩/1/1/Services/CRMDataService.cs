﻿using System.Collections.Generic;
using System.IO;
using Newtonsoft.Json;
using X.Models;

namespace X.Services
{
    public class CRMDataService
    {
        private const string FilePath = "crm_data.json";
        public CRMDataService()
        {
            if (!File.Exists(FilePath))
            {
                File.WriteAllText(FilePath, JsonConvert.SerializeObject(new
                {
                    Clients = new List<ClientModel>(),
                    Orders = new List<OrderModel>()
                }, Formatting.Indented));
            }
        }
        public (List<ClientModel> Clients, List<OrderModel> Orders) LoadData()
        {
            var json = File.ReadAllText(FilePath);
            var data = JsonConvert.DeserializeObject<dynamic>(json);
            var clients = JsonConvert.DeserializeObject<List<ClientModel>>(JsonConvert.SerializeObject(data.Clients)) ?? new List<ClientModel>();
            foreach (var client in clients)
            {
                client.DealsDescription = client.DealsDescription ?? string.Empty;
                client.Orders = client.Orders ?? new List<OrderModel>();
            }
            var orders = JsonConvert.DeserializeObject<List<OrderModel>>(JsonConvert.SerializeObject(data.Orders)) ?? new List<OrderModel>();
            return (clients, orders);
        }
        public void SaveData(List<ClientModel> clients, List<OrderModel> orders)
        {
            var data = new
            {
                Clients = clients,
                Orders = orders
            };
            File.WriteAllText(FilePath, JsonConvert.SerializeObject(data, Formatting.Indented));
        }
    }
}