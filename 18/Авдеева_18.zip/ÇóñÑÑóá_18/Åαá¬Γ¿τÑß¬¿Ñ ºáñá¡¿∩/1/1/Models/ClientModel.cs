﻿using System.Collections.Generic;
using System.ComponentModel;

namespace X.Models
{
    public class ClientModel : INotifyPropertyChanged
    {
        private string name;
        private string contact;
        private string email;
        private string type;
        private string dealsDescription;
        private List<OrderModel> orders = new List<OrderModel>();
        public string Name
        {
            get => name;
            set
            {
                name = value;
                OnPropertyChanged(nameof(Name));
            }
        }
        public string Contact
        {
            get => contact;
            set
            {
                contact = value;
                OnPropertyChanged(nameof(Contact));
            }
        }
        public string Email
        {
            get => email;
            set
            {
                email = value;
                OnPropertyChanged(nameof(Email));
            }
        }
        public string Type
        {
            get => type;
            set
            {
                type = value;
                OnPropertyChanged(nameof(Type));
            }
        }
        public string DealsDescription
        {
            get => dealsDescription;
            set
            {
                dealsDescription = value;
                OnPropertyChanged(nameof(DealsDescription));
            }
        }
        public List<OrderModel> Orders
        {
            get => orders;
            set
            {
                orders = value;
                OnPropertyChanged(nameof(Orders));
            }
        }
        public event PropertyChangedEventHandler PropertyChanged;
        protected void OnPropertyChanged(string pn)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(pn));
        }
    }
}