﻿using System.Windows;
using X.Models;

namespace X.Views
{
    public partial class ClientFormWindow : Window
    {
        public ClientModel Client { get; private set; }
        public string[] Types { get; } = { "VIP", "Обычный" };
        public ClientFormWindow(ClientModel client = null)
        {
            InitializeComponent();
            Client = client ?? new ClientModel();
            DataContext = this;
        }
        private void SaveButton_Click(object sender, RoutedEventArgs e)
        {
            DialogResult = true;
            Close();
        }
        private void CancelButton_Click(object sender, RoutedEventArgs e)
        {
            DialogResult = false;
            Close();
        }
    }
}