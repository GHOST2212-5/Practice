﻿using System.ComponentModel;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media.Animation;
using X.ViewModels;

namespace X.Views
{
    public partial class MainWindow : Window
    {
        // Отслеживание
        private bool isCardExpanded = false;

        public MainWindow()
        {
            InitializeComponent();
            DataContext = new CRMViewModel();

            if (DataContext is CRMViewModel vm)
            {
                vm.PropertyChanged += Vm_PropertyChanged;
            }
        }
        // Сброс и появление
        private async void Vm_PropertyChanged(object sender, PropertyChangedEventArgs e)
        {
            if (e.PropertyName == "SelectedClient")
            {
                // Скрытие
                ClientCard.Visibility = Visibility.Collapsed;
                // Отмена
                ClientCard.BeginAnimation(HeightProperty, null);
                ClientCard.Height = 50;
                ClientDetailsPanel.Visibility = Visibility.Collapsed;
                isCardExpanded = false;

                await Task.Delay(10);

                // Новая карточка
                ClientCard.Opacity = 0;
                ClientCard.Visibility = Visibility.Visible;
                // Анимации
                if (this.Resources["SlideInAnimation"] is Storyboard slideSb)
                {
                    slideSb.Begin(ClientCard);
                }
                if (this.Resources["FadeInAnimation"] is Storyboard fadeIn)
                {
                    fadeIn.Begin(ClientCard);
                }
            }
        }
        // Изменение цвета
        private void ClientCard_MouseEnter(object sender, MouseEventArgs e)
        {
            if (this.Resources["CardHoverEnterAnimation"] is Storyboard sb)
            {
                sb.Begin(ClientCard);
            }
        }
        private void ClientCard_MouseLeave(object sender, MouseEventArgs e)
        {
            if (this.Resources["CardHoverLeaveAnimation"] is Storyboard sb)
            {
                sb.Begin(ClientCard);
            }
        }

        // Проверка
        private async void ClientCard_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
        {
            if (ClientCard == null)
                return;

            if (!isCardExpanded)
            {
                if (this.Resources["ExpandCardAnimation"] is Storyboard expandSb)
                {
                    expandSb.Begin(ClientCard);
                }
                await Task.Delay(300);
                ClientDetailsPanel.Visibility = Visibility.Visible;
                isCardExpanded = true;
            }
        }
    }
}